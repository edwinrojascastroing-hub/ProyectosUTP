module Aplicacion {
    requires Componentes;
    requires Utilidades;
    requires java.desktop;
    requires jdk.compiler;
    requires jdk.unsupported.desktop;
}