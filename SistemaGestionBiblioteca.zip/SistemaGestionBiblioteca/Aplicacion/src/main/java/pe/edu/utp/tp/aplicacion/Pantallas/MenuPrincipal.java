package pe.edu.utp.tp.aplicacion.Pantallas;

import pe.edu.utp.tp.aplicacion.SistemaBiblioteca;
import pe.edu.utp.tp.componentes.EntidadesPrincipales.Usuario;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MenuPrincipal extends JFrame {
    private final SistemaBiblioteca sistema;
    private Usuario usuarioActual;
    private JDialog dialogLogin;



    public MenuPrincipal() {
        sistema = SistemaBiblioteca.getInstance();
    mostrarLogin();

}

private void mostrarLogin() {
    dialogLogin = new JDialog(this, "Iniciar Sesión - Sistema de Biblioteca", true);
    dialogLogin.setSize(500, 500);
    dialogLogin.setLocationRelativeTo(null);
    dialogLogin.setLayout(new BorderLayout(10, 10));

    // Panel título con logo
    JPanel panelTitulo = new JPanel();
    panelTitulo.setBackground(new Color(41, 128, 185));

    panelTitulo.setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));
    panelTitulo.setLayout(new BoxLayout(panelTitulo, BoxLayout.Y_AXIS));

    /*JLabel lblLogo = new JLabel("CESITAR23");
    setVisible(true);
    lblLogo.setFont(new Font("Arial", Font.PLAIN, 48));
    lblLogo.setAlignmentX(Component.CENTER_ALIGNMENT);*/


    /*ImageIcon iconoGif = new ImageIcon(getClass().getResource("/imagenes/gif.gif"));
    JLabel lblGif = new JLabel(iconoGif);
    lblGif.setHorizontalAlignment(SwingConstants.CENTER);
    add(lblGif, BorderLayout.CENTER);
    lblGif.setPreferredSize(new Dimension(450, 500)); // área del GIF
    add(lblGif, BorderLayout.CENTER);*/



    JLabel lblTitulo = new JLabel("SISTEMA DE BIBLIOTECA");
    lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));
    lblTitulo.setForeground(Color.WHITE);
    lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);

    JLabel lblSubtitulo = new JLabel("Control de Préstamos y Catálogo");
    lblSubtitulo.setFont(new Font("Arial", Font.PLAIN, 12));
    lblSubtitulo.setForeground(new Color(236, 240, 241));
    lblSubtitulo.setAlignmentX(Component.CENTER_ALIGNMENT);

  /*  panelTitulo.add(lblLogo);
    panelTitulo.add(Box.createVerticalStrut(10));*/
   /* panelTitulo.add(lblGif);*/

    panelTitulo.add(lblTitulo);
    panelTitulo.add(Box.createVerticalStrut(5));
    panelTitulo.add(lblSubtitulo);
    panelTitulo.add(Box.createVerticalStrut(5));

    
    dialogLogin.add(panelTitulo, BorderLayout.NORTH);
    dialogLogin.setResizable(false);


    // Panel formulari
    JPanel panelForm = new JPanel(new GridLayout(3,2,5,10));
    panelForm.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
    
    panelForm.add(new JLabel("👤 Usuario:"));
    JTextField txtUsuario = new JTextField();
    txtUsuario.setFont(new Font("Arial", Font.BOLD, 10));
    panelForm.add(txtUsuario);

    panelForm.add(new JLabel("🔒 Contraseña:"));
    JPasswordField txtPassword = new JPasswordField();
    txtPassword.setFont(new Font("Arial", Font.BOLD, 10));
    panelForm.add(txtPassword);

    dialogLogin.add(panelForm, BorderLayout.CENTER);

    // Panel botones
    JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 20));
    JButton btnIngresar = new JButton("✓ Ingresar");
    JButton btnSalir = new JButton("✗ Salir");

    btnIngresar.setPreferredSize(new Dimension(120, 35));
    btnSalir.setPreferredSize(new Dimension(120, 35));

    btnIngresar.setBackground(new Color(46, 204, 113));
    btnIngresar.setForeground(Color.WHITE);
    btnIngresar.setFocusPainted(false);

    btnSalir.setBackground(new Color(231, 76, 60));
    btnSalir.setForeground(Color.WHITE);
    btnSalir.setFocusPainted(false);

    btnIngresar.addActionListener(e -> {
        String user = txtUsuario.getText().trim();
        String pass = new String(txtPassword.getPassword());
        Usuario usuario = sistema.getUsuarioController().iniciarSesion(user, pass);


            if (usuario == null) {
                txtUsuario.setText("");
                txtPassword.setText("");
                return;
            }

        usuarioActual = usuario;


        switch (usuarioActual.getTipoUsuario().name()) {
            case "ADMINISTRATIVO" -> iniciarMenuPrincipalAdministrador();
            case "ALUMNO" -> iniciarMenuPrincipalAlumno();
            default -> JOptionPane.showMessageDialog(dialogLogin,
                    "Tipo de usuario no reconocido.",
                    "Error",
                    JOptionPane.WARNING_MESSAGE);
            }

        dialogLogin.dispose();


    });
    

    btnSalir.addActionListener(e -> System.exit(0));

    // Enter para login
    txtPassword.addActionListener(e -> btnIngresar.doClick());
    panelBotones.add(btnIngresar);
    panelBotones.add(btnSalir);
    dialogLogin.add(panelBotones, BorderLayout.SOUTH);
    dialogLogin.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
    dialogLogin.setVisible(true);
}

private void iniciarMenuPrincipalAdministrador() {
    configurarVentana();
    crearComponentesAdministrador();
    setVisible(true);
}

    private void iniciarMenuPrincipalAlumno() {
        configurarVentana();
        crearComponentesAlumno();
        setVisible(true);
    }


private void configurarVentana() {
    setTitle("Sistema de Biblioteca - Menú Principal");
    setSize(1000, 700);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLocationRelativeTo(null);
    setLayout(new BorderLayout(10, 10));
}

private void crearComponentesAdministrador() {
    // Panel superior
    JPanel panelSuperior = getJPanel();
    add(panelSuperior, BorderLayout.NORTH);

    // Panel central con botones
    JPanel panelCentral = new JPanel(new GridLayout(4, 3, 20, 20));
    panelCentral.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

    agregarBoton(panelCentral, "📚\nGestión de\nAutores", new Color(52, 152, 219),
            e -> {new PantallaAutores().setVisible(true); dispose();});
    agregarBoton(panelCentral, "📖\nGestión de\nLibros", new Color(46, 204, 113),
            e -> {new PantallaLibros().setVisible(true); dispose(); } );



   /* agregarBoton(panelCentral, "📕\nGestión de\nEjemplares", new Color(155, 89, 182),
            e -> new PantallaEjemplares().setVisible(true));
    agregarBoton(panelCentral, "👥\nGestión de\nUsuarios", new Color(241, 196, 15),
            e -> new PantallaUsuarios().setVisible(true));
    agregarBoton(panelCentral, "🔄\nRegistro de\nPréstamos", new Color(231, 76, 60),
            e -> new PantallaPrestamos().setVisible(true));
    agregarBoton(panelCentral, "✅\nRegistro de\nDevoluciones", new Color(26, 188, 156),
            e -> new PantallaDevoluciones().setVisible(true));
    agregarBoton(panelCentral, "📋\nConsulta de\nPréstamos", new Color(52, 73, 94),
            e -> new PantallaConsultaPrestamos().setVisible(true));
    agregarBoton(panelCentral, "📊\nReportes del\nSistema", new Color(149, 165, 166),
            e -> new PantallaReportes().setVisible(true));
    agregarBoton(panelCentral, "📦\nReportes de\nInventario", new Color(22, 160, 133),
            e -> new ReportesInventario().setVisible(true));*/
    agregarBoton(panelCentral, "ℹ️\nAcerca de", new Color(52, 152, 219),
            e -> mostrarAcercaDe());
    agregarBoton(panelCentral, "⚙️\nConfiguración", new Color(189, 195, 199),
            e -> mostrarConfiguracion());
    agregarBoton(panelCentral, "🔄\nCerrar Sesión", new Color(243, 156, 18),
            e -> cerrarSesion());

    add(panelCentral, BorderLayout.CENTER);

    // Panel inferior
    JPanel panelInferior = getPanel();

    add(panelInferior, BorderLayout.SOUTH);
}


    private void crearComponentesAlumno() {
        // Panel superior
        JPanel panelSuperior = getJPanel();
        add(panelSuperior, BorderLayout.NORTH);


        // Panel central con botones
        JPanel panelCentral = new JPanel(new GridLayout(4, 3, 20, 20));
        panelCentral.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

       /* agregarBoton(panelCentral, "📚\nGestión de\nAutores", new Color(52, 152, 219),
                e -> new PantallaAutores().setVisible(true));
        agregarBoton(panelCentral, "📖\nGestión de\nLibros", new Color(46, 204, 113),
                e -> new PantallaLibros().setVisible(true));*/
   /*agregarBoton(panelCentral, "📕\nGestión de\nEjemplares", new Color(155, 89, 182),
            e -> new PantallaEjemplares().setVisible(true));/*/
    /*agregarBoton(panelCentral, "👥\nGestión de\nUsuarios", new Color(241, 196, 15),
            e -> new PantallaUsuarios().setVisible(true));*/
    agregarBoton(panelCentral, "🔄\nRegistro de\nPréstamos", new Color(231, 76, 60),
            e -> {new PantallaPrestamos().setVisible(true); dispose();});


  /*  agregarBoton(panelCentral, "✅\nRegistro de\nDevoluciones", new Color(26, 188, 156),
            e -> new PantallaDevoluciones().setVisible(true));
    agregarBoton(panelCentral, "📋\nConsulta de\nPréstamos", new Color(52, 73, 94),
            e -> new PantallaConsultaPrestamos().setVisible(true));
    agregarBoton(panelCentral, "📊\nReportes del\nSistema", new Color(149, 165, 166),
            e -> new PantallaReportes().setVisible(true));
    agregarBoton(panelCentral, "📦\nReportes de\nInventario", new Color(22, 160, 133),
            e -> new ReportesInventario().setVisible(true));*/
        agregarBoton(panelCentral, "ℹ️\nAcerca de", new Color(52, 152, 219),
                e -> mostrarAcercaDe());
        agregarBoton(panelCentral, "⚙️\nConfiguración", new Color(189, 195, 199),
                e -> mostrarConfiguracion());
        agregarBoton(panelCentral, "🔄\nCerrar Sesión", new Color(243, 156, 18),
                e -> cerrarSesion());

        add(panelCentral, BorderLayout.CENTER);

        // Panel inferior
        JPanel panelInferior = getPanel();

        add(panelInferior, BorderLayout.SOUTH);
    }

    private static JPanel getPanel() {
        JPanel panelInferior = new JPanel(new BorderLayout());
        panelInferior.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JLabel lblInfo = new JLabel("Sistema desarrollado con Listas Enlazadas, Colas y Nodos | © 2025");
        lblInfo.setFont(new Font("Arial", Font.ITALIC, 11));
        panelInferior.add(lblInfo, BorderLayout.WEST);

        JLabel lblVersion = new JLabel("Versión 1.0");
        lblVersion.setFont(new Font("Arial", Font.ITALIC, 11));
        panelInferior.add(lblVersion, BorderLayout.EAST);
        return panelInferior;
    }

    private  JPanel getJPanel() {
        JPanel panelSuperior = new JPanel(new BorderLayout());
        panelSuperior.setBackground(new Color(41, 128, 185));
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel panelTituloIcon = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelTituloIcon.setOpaque(false);
        JLabel lblIcon = new JLabel("📚 ");
        lblIcon.setFont(new Font("Arial", Font.PLAIN, 28));
        JLabel lblTitulo = new JLabel("SISTEMA DE GESTIÓN DE BIBLIOTECA");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));
        lblTitulo.setForeground(Color.WHITE);
        panelTituloIcon.add(lblIcon);
        panelTituloIcon.add(lblTitulo);
        panelSuperior.add(panelTituloIcon, BorderLayout.WEST);

        String u = usuarioActual.getTipoUsuario().name();
        JLabel lblUsuarioActual = new JLabel( );
        lblUsuarioActual.setText(
                      "<html>👋 Hola, " + usuarioActual.getNombre() + "<br>" + u.substring(0, 1).toUpperCase() + u.substring(1).toLowerCase() + "</html>");

        lblUsuarioActual.setFont(new Font("Arial", Font.PLAIN, 14));
        lblUsuarioActual.setForeground(Color.WHITE);
        panelSuperior.add(lblUsuarioActual, BorderLayout.EAST);

        return panelSuperior;
    }

    private void agregarBoton(JPanel panel, String texto, Color color, ActionListener action) {
    JButton btn = new JButton("<html><center>" + texto.replace("\n", "<br>") + "</center></html>");
    btn.setFont(new Font("Arial", Font.BOLD, 14));
    btn.setBackground(color);
    btn.setForeground(Color.WHITE);
    btn.setFocusPainted(false);
    btn.setBorderPainted(false);
    btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

    // Efecto hover
    btn.addMouseListener(new MouseAdapter() {
        public void mouseEntered(MouseEvent e) {
            btn.setBackground(color.darker());
        }
        public void mouseExited(MouseEvent e) {
            btn.setBackground(color);
        }
    });

    btn.addActionListener(action);
    panel.add(btn);
}

private void mostrarAcercaDe() {
    JDialog dialog = new JDialog(this, "Acerca del Sistema", true);
    dialog.setSize(600, 500);
    dialog.setLocationRelativeTo(this);
    dialog.setLayout(new BorderLayout(10, 10));

    // Panel superior con logo
    JPanel panelLogo = new JPanel();
    panelLogo.setBackground(new Color(41, 128, 185));
    panelLogo.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
    JLabel lblLogo = new JLabel("📚 SISTEMA DE BIBLIOTECA");
    lblLogo.setFont(new Font("Arial", Font.BOLD, 24));
    lblLogo.setForeground(Color.WHITE);
    panelLogo.add(lblLogo);
    dialog.add(panelLogo, BorderLayout.NORTH);

    // Contenido
    JTextArea txtAcerca = new JTextArea();
    txtAcerca.setEditable(false);
    txtAcerca.setFont(new Font("Monospaced", Font.PLAIN, 12));
    txtAcerca.setMargin(new Insets(15, 15, 15, 15));

    StringBuilder sb = new StringBuilder();
    sb.append("SISTEMA DE GESTIÓN DE BIBLIOTECA\n");
    sb.append("═══════════════════════════════════════════════════\n\n");
    sb.append("Versión: 1.0\n");
    sb.append("Año: 2025\n\n");

    sb.append("CARACTERÍSTICAS PRINCIPALES:\n");
    sb.append("───────────────────────────────────────────────────\n");
    sb.append("• Gestión completa de catálogo (Autores, Libros, Ejemplares)\n");
    sb.append("• Control de usuarios (Alumnos, Docentes, Administrativos)\n");
    sb.append("• Sistema de préstamos y devoluciones\n");
    sb.append("• Cálculo automático de multas\n");
    sb.append("• Lista de espera con cola FIFO\n");
    sb.append("• Reportes estadísticos completos\n");
    sb.append("• Límites personalizados por tipo de usuario\n\n");

    sb.append("LÍMITES DE PRÉSTAMO:\n");
    sb.append("───────────────────────────────────────────────────\n");
    sb.append("• Alumnos:          3 libros / 7 días\n");
    sb.append("• Docentes:         5 libros / 30 días\n");
    sb.append("• Administrativos:  2 libros / 10 días\n\n");

    sb.append("SISTEMA DE MULTAS:\n");
    sb.append("───────────────────────────────────────────────────\n");
    sb.append("• Días de gracia: 2 días\n");
    sb.append("• Tarifa: S/. 2.00 por día de retraso\n\n");

    sb.append("ESTRUCTURAS DE DATOS:\n");
    sb.append("───────────────────────────────────────────────────\n");
    sb.append("• Listas Enlazadas - Para almacenamiento de datos\n");
    sb.append("• Colas (FIFO) - Para lista de espera\n");
    sb.append("• Nodos personalizados - Para estructura flexible\n\n");

    sb.append("PATRONES DE DISEÑO:\n");
    sb.append("───────────────────────────────────────────────────\n");
    sb.append("• Repository Pattern - Capa de persistencia\n");
    sb.append("• Singleton - Instancia única del sistema\n");
    sb.append("• MVC - Separación de capas\n");
    sb.append("• Observer - Actualización de UI\n");
    sb.append("• Strategy - Validación de préstamos\n");
    sb.append("• Facade - Servicios simplificados\n\n");

    sb.append("CREDENCIALES:\n");
    sb.append("───────────────────────────────────────────────────\n");
    sb.append("• Usuario: admin | Contraseña: admin\n");
    sb.append("• Usuario: biblio | Contraseña: biblio\n");

    txtAcerca.setText(sb.toString());
    dialog.add(new JScrollPane(txtAcerca), BorderLayout.CENTER);

    // Botón cerrar
    JPanel panelBoton = new JPanel();
    JButton btnCerrar = new JButton("Cerrar");
    btnCerrar.setPreferredSize(new Dimension(100, 30));
    btnCerrar.addActionListener(e -> dialog.dispose());
    panelBoton.add(btnCerrar);
    dialog.add(panelBoton, BorderLayout.SOUTH);

    dialog.setVisible(true);
}

private void mostrarConfiguracion() {
    JDialog dialog = new JDialog(this, "Configuración del Sistema", true);
    dialog.setSize(600, 500);
    dialog.setLocationRelativeTo(this);
    dialog.setLayout(new BorderLayout(10, 10));

    // Título
    JPanel panelTitulo = new JPanel();
    panelTitulo.setBackground(new Color(189, 195, 199));
    panelTitulo.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
    JLabel lblTitulo = new JLabel("⚙️ CONFIGURACIÓN DEL SISTEMA");
    lblTitulo.setFont(new Font("Arial", Font.BOLD, 20));
    lblTitulo.setForeground(Color.WHITE);
    panelTitulo.add(lblTitulo);
    dialog.add(panelTitulo, BorderLayout.NORTH);

    // Panel de configuración
    JPanel panelConfig = new JPanel();
    panelConfig.setLayout(new BoxLayout(panelConfig, BoxLayout.Y_AXIS));
    panelConfig.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

    // Sección: Límites de Préstamo
    JPanel seccionLimites = crearSeccionConfig("LÍMITES DE PRÉSTAMO");
    seccionLimites.add(crearFilaConfig("Alumnos:", "3 libros | 7 días"));
    seccionLimites.add(crearFilaConfig("Docentes:", "5 libros | 30 días"));
    seccionLimites.add(crearFilaConfig("Administrativos:", "2 libros | 10 días"));
    panelConfig.add(seccionLimites);
    panelConfig.add(Box.createVerticalStrut(20));

    // Sección: Multas
    JPanel seccionMultas = crearSeccionConfig("CONFIGURACIÓN DE MULTAS");
    seccionMultas.add(crearFilaConfig("Días de gracia:", "2 días"));
    seccionMultas.add(crearFilaConfig("Tarifa por día:", "S/. 2.00"));
    seccionMultas.add(crearFilaConfig("Multa máxima:", "Sin límite"));
    panelConfig.add(seccionMultas);
    panelConfig.add(Box.createVerticalStrut(20));

    // Sección: Sistema
    JPanel seccionSistema = crearSeccionConfig("CONFIGURACIÓN DEL SISTEMA");
    seccionSistema.add(crearFilaConfig("Estructura de datos:", "Listas Enlazadas"));
    seccionSistema.add(crearFilaConfig("Cola de espera:", "FIFO"));
    seccionSistema.add(crearFilaConfig("Total de usuarios:",
            String.valueOf(sistema.getUsuarioService().listarTodos().getSize())));
    seccionSistema.add(crearFilaConfig("Total de libros:",
            String.valueOf(sistema.getLibroService().listarTodos().getSize())));
    seccionSistema.add(crearFilaConfig("Préstamos activos:",
            String.valueOf(sistema.getPrestamoService().consultarPrestamosActivos().getSize())));
    panelConfig.add(seccionSistema);

    dialog.add(new JScrollPane(panelConfig), BorderLayout.CENTER);

    // Botones
    JPanel panelBotones = new JPanel(new FlowLayout());
    JButton btnGuardar = new JButton("💾 Guardar");
    JButton btnRestaurar = new JButton("🔄 Restaurar");
    JButton btnCerrar = new JButton("❌ Cerrar");

    btnGuardar.addActionListener(e -> {
        JOptionPane.showMessageDialog(dialog,
                "Configuración guardada exitosamente",
                "Éxito", JOptionPane.INFORMATION_MESSAGE);
    });

    btnRestaurar.addActionListener(e -> {
        int confirm = JOptionPane.showConfirmDialog(dialog,
                "¿Restaurar configuración por defecto?",
                "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(dialog,
                    "Configuración restaurada",
                    "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
    });

    btnCerrar.addActionListener(e -> dialog.dispose());

    panelBotones.add(btnGuardar);
    panelBotones.add(btnRestaurar);
    panelBotones.add(btnCerrar);
    dialog.add(panelBotones, BorderLayout.SOUTH);

    dialog.setVisible(true);
}

private JPanel crearSeccionConfig(String titulo) {
    JPanel panel = new JPanel();
    panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
    panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Color.GRAY), titulo));
    return panel;
}

private JPanel crearFilaConfig(String etiqueta, String valor) {
    JPanel panel = new JPanel(new BorderLayout());
    panel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

    JLabel lblEtiqueta = new JLabel(etiqueta);
    lblEtiqueta.setFont(new Font("Arial", Font.BOLD, 12));

    JLabel lblValor = new JLabel(valor);
    lblValor.setFont(new Font("Arial", Font.PLAIN, 12));
    lblValor.setForeground(new Color(52, 73, 94));

    panel.add(lblEtiqueta, BorderLayout.WEST);
    panel.add(lblValor, BorderLayout.EAST);

    return panel;
}

private void cerrarSesion() {
    int confirm = JOptionPane.showConfirmDialog(this,
            "¿Está seguro de cerrar sesión?",
            "Cerrar Sesión",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);

    if (confirm == JOptionPane.YES_OPTION) {
        dispose();
        new MenuPrincipal();
    }
}

// Método main para iniciar la aplicación
public static void main(String[] args) {
    // Configurar look and feel
    try {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    } catch (Exception e) {
        e.printStackTrace();
    }

    // Iniciar en el hilo de eventos de Swing
    SwingUtilities.invokeLater(() -> {
        new MenuPrincipal();
    });
}
}



