package pe.edu.utp.tp.aplicacion.Pantallas;

import pe.edu.utp.tp.aplicacion.SistemaBiblioteca;
import pe.edu.utp.tp.componentes.EntidadesPrincipales.Administrativo;
import pe.edu.utp.tp.componentes.EntidadesPrincipales.Alumno;
import pe.edu.utp.tp.componentes.EntidadesPrincipales.Prestamo;
import pe.edu.utp.tp.componentes.EntidadesPrincipales.Usuario;
import pe.edu.utp.tp.componentes.ListasEnlazadas.ListaEnlazada;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PantallaUsuarios extends JFrame {
    private SistemaBiblioteca sistema;
    private JTable tabla;
    private DefaultTableModel modelo;
    private JTextField txtCodigo, txtNombre, txtpassword, txtEmail, txtTelefono;
    private JTextField txtExtra1, txtExtra2, txtExtra3;
    private JLabel lblExtra1, lblExtra2, lblExtra3;
    private JComboBox<String> cboTipo;
    private JTextArea txtInfo;



    public PantallaUsuarios() {
        sistema = SistemaBiblioteca.getInstance();
        configurarVentana();
        crearComponentes();
        cargarDatos();
    }

    private void configurarVentana() {
        setTitle("Gestión de Usuarios");
        setSize(1100, 650);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));
    }

    private void crearComponentes() {
        add(crearPanelTitulo("GESTIÓN DE USUARIOS", new Color(241, 196, 15)), BorderLayout.NORTH);

        // Panel izquierdo
        JPanel panelIzq = new JPanel();
        panelIzq.setLayout(new BoxLayout(panelIzq, BoxLayout.Y_AXIS));
        panelIzq.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelIzq.setPreferredSize(new Dimension(350, 0));

        // Formulario básico
        JPanel panelForm = new JPanel(new GridLayout(5, 2, 5, 10));
        panelForm.setBorder(BorderFactory.createTitledBorder("Datos Básicos"));

        panelForm.add(new JLabel("Código:"));
        txtCodigo = new JTextField();
        panelForm.add(txtCodigo);

        panelForm.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        panelForm.add(txtNombre);

        /*panelForm.add(new JLabel("Dirección:"));
        txtDireccion = new JTextField();
        panelForm.add(txtDireccion);*/

        panelForm.add(new JLabel("Teléfono:"));
        txtTelefono = new JTextField();
        panelForm.add(txtTelefono);

        panelForm.add(new JLabel("Tipo:"));
        cboTipo = new JComboBox<>(new String[]{"Alumno", "Docente", "Administrativo"});
        cboTipo.addActionListener(e -> actualizarCamposDinamicos());
        panelForm.add(cboTipo);

        panelIzq.add(panelForm);
        panelIzq.add(Box.createVerticalStrut(10));

        // Campos dinámicos
        JPanel panelDinamico = new JPanel(new GridLayout(3, 2, 5, 10));
        panelDinamico.setBorder(BorderFactory.createTitledBorder("Datos Específicos"));

        lblExtra1 = new JLabel("Grado:");
        txtExtra1 = new JTextField();
        panelDinamico.add(lblExtra1);
        panelDinamico.add(txtExtra1);

        lblExtra2 = new JLabel("Sección:");
        txtExtra2 = new JTextField();
        panelDinamico.add(lblExtra2);
        panelDinamico.add(txtExtra2);

        lblExtra3 = new JLabel("Cód. Estudiante:");
        txtExtra3 = new JTextField();
        panelDinamico.add(lblExtra3);
        panelDinamico.add(txtExtra3);

        panelIzq.add(panelDinamico);
        panelIzq.add(Box.createVerticalStrut(10));

        // Botones
        JPanel panelBotones = new JPanel(new GridLayout(6, 1, 5, 5));
        JButton btnRegistrar = new JButton("Registrar Usuario");
        JButton btnActualizar = new JButton("Actualizar Datos");
        JButton btnHistorial = new JButton("Ver Historial");
        JButton btnMultas = new JButton("Ver Multas");
        JButton btnBuscar = new JButton("Buscar por Nombre");
        JButton btnTodos = new JButton("Mostrar Todos");

        btnRegistrar.addActionListener(e -> registrarUsuario());
        btnActualizar.addActionListener(e -> actualizarDatos());
        btnHistorial.addActionListener(e -> verHistorial());
        btnMultas.addActionListener(e -> verMultas());
        btnBuscar.addActionListener(e -> buscarPorNombre());
        btnTodos.addActionListener(e -> cargarDatos());

        panelBotones.add(btnRegistrar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnHistorial);
        panelBotones.add(btnMultas);
        panelBotones.add(btnBuscar);
        panelBotones.add(btnTodos);

        panelIzq.add(panelBotones);

        // Panel de información
        JPanel panelInfo = new JPanel(new BorderLayout());
        panelInfo.setBorder(BorderFactory.createTitledBorder("Información Detallada"));
        txtInfo = new JTextArea(8, 20);
        txtInfo.setEditable(false);
        txtInfo.setLineWrap(true);
        panelInfo.add(new JScrollPane(txtInfo), BorderLayout.CENTER);
        panelIzq.add(panelInfo);

        add(panelIzq, BorderLayout.WEST);

        // Tabla
        String[] columnas = {"Código", "Nombre", "Tipo", "Teléfono", "Días Préstamo"};
        modelo = new DefaultTableModel(columnas, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        tabla = new JTable(modelo);
        tabla.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) seleccionarFila();
            }
        });

        add(new JScrollPane(tabla), BorderLayout.CENTER);
    }

    private void actualizarCamposDinamicos() {
        String tipo = (String) cboTipo.getSelectedItem();
        switch (tipo) {
            case "Alumno":
                lblExtra1.setText("Grado:");
                lblExtra2.setText("Sección:");
                lblExtra3.setText("Cód. Estudiante:");
                txtExtra3.setEnabled(true);
                break;
            case "Docente":
                lblExtra1.setText("Departamento:");
                lblExtra2.setText("Especialidad:");
                lblExtra3.setText("");
                txtExtra3.setText("");
                txtExtra3.setEnabled(false);
                break;
            case "Administrativo":
                lblExtra1.setText("Área:");
                lblExtra2.setText("Cargo:");
                lblExtra3.setText("");
                txtExtra3.setText("");
                txtExtra3.setEnabled(false);
                break;
        }
    }

    private void registrarUsuario() {
        String codigo = txtCodigo.getText().trim();
        String password = txtpassword.getText().trim();
        String nombre = txtNombre.getText().trim();
       String email = txtEmail.getText().trim();
        String telefono = txtTelefono.getText().trim();
        String tipo = (String) cboTipo.getSelectedItem();

        if (codigo.isEmpty() || nombre.isEmpty()) {
            mostrarError("Complete los campos obligatorios");
            return;
        }

        boolean exito = false;

        switch (tipo) {
            case "Alumno":
                exito = sistema.getUsuarioService().crearAlumno(
                        codigo,password, nombre, email, telefono,
                        txtExtra1.getText().trim(),
                        txtExtra2.getText().trim(),
                        txtExtra3.getText().trim()
                );
                break;
           case "Docente":
                exito = sistema.getUsuarioService().crearDocente(
                        codigo, password, nombre, email, telefono,
                        txtExtra1.getText().trim(),
                        txtExtra2.getText().trim()
                );
                break;
            case "Administrativo":
                exito = sistema.getUsuarioService().crearAdministrativo(
                        codigo, password, nombre, email, telefono,
                        txtExtra1.getText().trim(),
                        txtExtra2.getText().trim()
                );
                break;
        }

        if (exito) {
            mostrarExito("Usuario registrado exitosamente");
            cargarDatos();
            limpiarCampos();
        } else {
            mostrarError("El código ya existe");
        }
    }

    private void actualizarDatos() {
        String codigo = txtCodigo.getText().trim();

        if (codigo.isEmpty()) {
            mostrarError("Seleccione un usuario");
            return;
        }

        Usuario usuario = sistema.getUsuarioService().buscar(codigo);
        if (usuario != null) {
            usuario.setNombre(txtNombre.getText().trim());

            usuario.setTelefono(txtTelefono.getText().trim());
            mostrarExito("Datos actualizados");
            cargarDatos();
        } else {
            mostrarError("Usuario no encontrado");
        }
    }

    private void verHistorial() {
        String codigo = txtCodigo.getText().trim();

        if (codigo.isEmpty()) {
            mostrarError("Seleccione un usuario");
            return;
        }

        Usuario usuario = sistema.getUsuarioService().buscar(codigo);
        if (usuario == null) {
            mostrarError("Usuario no encontrado");
            return;
        }

        ListaEnlazada<Prestamo> historial = sistema.getPrestamoService().consultarPrestamosPorUsuario(codigo);

        StringBuilder sb = new StringBuilder();
        sb.append("═══ HISTORIAL DE PRÉSTAMOS ═══\n");
        sb.append("Usuario: ").append(usuario.getNombre()).append("\n");
        sb.append("Código: ").append(codigo).append("\n\n");
        sb.append("Total préstamos: ").append(historial.getSize()).append("\n\n");

        if (historial.getSize() == 0) {
            sb.append("No tiene préstamos registrados");
        } else {
            final int[] contador = {1};
            historial.recorrer(p -> {
                sb.append(contador[0]++).append(". Código: ").append(p.getCodigoPrestamo()).append("\n");
                sb.append("   Ejemplar: ").append(p.getCodigoEjemplar()).append("\n");
                sb.append("   Fecha: ").append(p.getFechaPrestamo()).append("\n");
                sb.append("   Estado: ").append(p.estaActivo() ? "ACTIVO" : "DEVUELTO").append("\n");
                if (p.isTieneMulta()) {
                    sb.append("   Multa: S/. ").append(String.format("%.2f", p.getMontoMulta())).append("\n");
                }
                sb.append("   ───────────────\n");
            });
        }

        txtInfo.setText(sb.toString());
    }

    private void verMultas() {
        String codigo = txtCodigo.getText().trim();

        if (codigo.isEmpty()) {
            mostrarError("Seleccione un usuario");
            return;
        }

        Usuario usuario = sistema.getUsuarioService().buscar(codigo);
        if (usuario == null) {
            mostrarError("Usuario no encontrado");
            return;
        }

        ListaEnlazada<Prestamo> prestamos = sistema.getPrestamoService().consultarPrestamosPorUsuario(codigo);
        ListaEnlazada<Prestamo> conMulta = prestamos.filtrar(p -> p.isTieneMulta());

        StringBuilder sb = new StringBuilder();
        sb.append("═══ MULTAS PENDIENTES ═══\n");
        sb.append("Usuario: ").append(usuario.getNombre()).append("\n\n");

        if (conMulta.getSize() == 0) {
            sb.append("✓ No tiene multas pendientes");
        } else {
            final double[] total = {0.0};
            conMulta.recorrer(p -> {
                sb.append("Préstamo: ").append(p.getCodigoPrestamo()).append("\n");
                sb.append("Monto: S/. ").append(String.format("%.2f", p.getMontoMulta())).append("\n");
                sb.append("───────────────\n");
                total[0] += p.getMontoMulta();
            });
            sb.append("\n💰 TOTAL MULTAS: S/. ").append(String.format("%.2f", total[0]));
        }

        txtInfo.setText(sb.toString());
    }

    private void buscarPorNombre() {
        String nombre = JOptionPane.showInputDialog(this, "Ingrese el nombre a buscar:");
        if (nombre != null && !nombre.trim().isEmpty()) {
            modelo.setRowCount(0);
            ListaEnlazada<Usuario> resultados = sistema.getUsuarioService().buscarPorNombre(nombre);

            if (resultados.getSize() == 0) {
                mostrarInfo("No se encontraron resultados");
            }

            resultados.recorrer(u ->
                    modelo.addRow(new Object[]{
                            u.getCodigoUsuario(),
                            u.getNombre(),
                            u.getTipoUsuario(),
                            u.getTelefono(),
                            u.getDiasMaximoPrestamo()
                    })
            );
        }
    }

    private void seleccionarFila() {
        int fila = tabla.getSelectedRow();
        if (fila >= 0) {
            String codigo = modelo.getValueAt(fila, 0).toString();
            Usuario usuario = sistema.getUsuarioService().buscar(codigo);

            if (usuario != null) {
                txtCodigo.setText(usuario.getCodigoUsuario());
                txtNombre.setText(usuario.getNombre());

                txtTelefono.setText(usuario.getTelefono());

                switch (usuario.getTipoUsuario()) {
                    case ALUMNO:
                        cboTipo.setSelectedItem("Alumno");
                        Alumno alumno = (Alumno) usuario;
                        txtExtra1.setText(alumno.getGrado());
                        txtExtra2.setText(alumno.getSeccion());
                        txtExtra3.setText(alumno.getCodigoEstudiante());
                        break;
                   /* case DOCENTE:
                        cboTipo.setSelectedItem("Docente");
                        Docente docente = (Docente) usuario;
                        txtExtra1.setText(docente.getDepartamento());
                        txtExtra2.setText(docente.getEspecialidad());
                        break;*/
                    case ADMINISTRATIVO:
                        cboTipo.setSelectedItem("Administrativo");
                        Administrativo admin = (Administrativo) usuario;
                        txtExtra1.setText(admin.getArea());
                        txtExtra2.setText(admin.getCargo());
                        break;
                }
            }
        }
    }

    private void cargarDatos() {
        modelo.setRowCount(0);
        sistema.getUsuarioService().listarTodos().recorrer(u ->
                modelo.addRow(new Object[]{
                        u.getCodigoUsuario(),
                        u.getNombre(),
                        u.getTipoUsuario(),
                        u.getTelefono(),
                        u.getDiasMaximoPrestamo()
                })
        );
    }

    private void limpiarCampos() {
        txtCodigo.setText("");
        txtNombre.setText("");
        txtEmail.setText("");
        txtTelefono.setText("");
        txtExtra1.setText("");
        txtExtra2.setText("");
        txtExtra3.setText("");
        txtInfo.setText("");
    }

    private JPanel crearPanelTitulo(String texto, Color color) {
        JPanel panel = new JPanel();
        panel.setBackground(color);
        JLabel lbl = new JLabel(texto);
        lbl.setFont(new Font("Arial", Font.BOLD, 20));
        lbl.setForeground(Color.WHITE);
        panel.add(lbl);
        return panel;
    }

    private void mostrarError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void mostrarExito(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }

    private void mostrarInfo(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Información", JOptionPane.INFORMATION_MESSAGE);
    }
}


