package pe.edu.utp.tp.aplicacion;


import pe.edu.utp.tp.aplicacion.Pantallas.MenuPrincipal;
import pe.edu.utp.tp.aplicacion.Pantallas.PantallaPrestamos;
import pe.edu.utp.tp.aplicacion.Pantallas.PantallaUsuarios;

import javax.swing.*;

public class App {
    public static void main(String[] args) {
      SwingUtilities.invokeLater(() -> {
          MenuPrincipal ventana = new MenuPrincipal(); ventana.setVisible(true); ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  });
    }

}
