package pe.edu.utp.tp.aplicacion.Pantallas;

import pe.edu.utp.tp.aplicacion.SistemaBiblioteca;
import pe.edu.utp.tp.componentes.EntidadesPrincipales.Libro;
import pe.edu.utp.tp.componentes.ListasEnlazadas.ListaEnlazada;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PantallaLibros extends JFrame {
    private SistemaBiblioteca sistema;
    private JTable tabla;
    private DefaultTableModel modelo;
    private JTextField txtCodigo, txtTitulo, txtISBN, txtEditorial, txtPaginas, txtBuscar;
    private JTextArea txtAutores;
    private JComboBox<String> cboBusqueda;
    private JButton btnNuevo, btnGuardar, btnModificar, btnEliminar;
    private boolean modoEdicion = false;

    public PantallaLibros() {
        sistema = SistemaBiblioteca.getInstance();
        configurarVentana();
        crearComponentes();
        cargarDatos();
    }

    private void configurarVentana() {
        setTitle("Gestión de Libros");
        setSize(1100, 650);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));
    }

    private void crearComponentes() {
        // Título
        add(crearPanelTitulo("GESTIÓN DE LIBROS", new Color(46, 204, 113)), BorderLayout.NORTH);

        // Panel izquierdo - Formulario
        JPanel panelIzq = new JPanel();
        panelIzq.setLayout(new BoxLayout(panelIzq, BoxLayout.Y_AXIS));
        panelIzq.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelIzq.setPreferredSize(new Dimension(350, 0));

        JPanel panelForm = new JPanel(new GridLayout(6, 2, 5, 10));
        panelForm.setBorder(BorderFactory.createTitledBorder("Datos del Libro"));

        panelForm.add(new JLabel("Código:"));
        txtCodigo = new JTextField();
        panelForm.add(txtCodigo);

        panelForm.add(new JLabel("Título:"));
        txtTitulo = new JTextField();
        panelForm.add(txtTitulo);

        panelForm.add(new JLabel("ISBN:"));
        txtISBN = new JTextField();
        panelForm.add(txtISBN);

        panelForm.add(new JLabel("Editorial:"));
        txtEditorial = new JTextField();
        panelForm.add(txtEditorial);

        panelForm.add(new JLabel("Páginas:"));
        txtPaginas = new JTextField();
        panelForm.add(txtPaginas);

        panelIzq.add(panelForm);

        // Autores
        JPanel panelAutores = new JPanel(new BorderLayout());
        panelAutores.setBorder(BorderFactory.createTitledBorder("Códigos de Autores (separados por coma)"));
        txtAutores = new JTextArea(3, 20);
        txtAutores.setLineWrap(true);
        panelAutores.add(new JScrollPane(txtAutores), BorderLayout.CENTER);

        JButton btnVerAutores = new JButton("Ver Autores Disponibles");
        btnVerAutores.addActionListener(e -> mostrarAutoresDisponibles());
        panelAutores.add(btnVerAutores, BorderLayout.SOUTH);

        panelIzq.add(panelAutores);

        // Botones
        JPanel panelBotones = new JPanel(new GridLayout(4, 1, 5, 5));
        btnNuevo = new JButton("Nuevo");
        btnGuardar = new JButton("Guardar");
        btnModificar = new JButton("Modificar");
        btnEliminar = new JButton("Eliminar");

        btnNuevo.addActionListener(e -> nuevo());
        btnGuardar.addActionListener(e -> guardar());
        btnModificar.addActionListener(e -> modificar());
        btnEliminar.addActionListener(e -> eliminar());

        panelBotones.add(btnNuevo);
        panelBotones.add(btnGuardar);
        panelBotones.add(btnModificar);
        panelBotones.add(btnEliminar);

        panelIzq.add(panelBotones);
        add(panelIzq, BorderLayout.WEST);

        // Panel central
        JPanel panelCentral = new JPanel(new BorderLayout(5, 5));

        // Búsqueda avanzada
        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelBusqueda.add(new JLabel("Buscar por:"));
        cboBusqueda = new JComboBox<>(new String[]{"Título", "ISBN", "Editorial"});
        panelBusqueda.add(cboBusqueda);
        txtBuscar = new JTextField(20);
        panelBusqueda.add(txtBuscar);

        JButton btnBuscar = new JButton("🔍 Buscar");
        JButton btnTodos = new JButton("Mostrar Todos");
        btnBuscar.addActionListener(e -> buscarAvanzado());
        btnTodos.addActionListener(e -> cargarDatos());

        panelBusqueda.add(btnBuscar);
        panelBusqueda.add(btnTodos);
        panelCentral.add(panelBusqueda, BorderLayout.NORTH);

        // Tabla
        String[] columnas = {"Código", "Título", "ISBN", "Editorial", "Páginas"};
        modelo = new DefaultTableModel(columnas, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        tabla = new JTable(modelo);
        tabla.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) seleccionarFila();
            }
        });

        panelCentral.add(new JScrollPane(tabla), BorderLayout.CENTER);
        add(panelCentral, BorderLayout.CENTER);

        configurarEstadoInicial();
    }

    private void configurarEstadoInicial() {
        txtCodigo.setEnabled(false);
        txtTitulo.setEnabled(false);
        txtISBN.setEnabled(false);
        txtEditorial.setEnabled(false);
        txtPaginas.setEnabled(false);
        txtAutores.setEnabled(false);
        btnGuardar.setEnabled(false);
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
    }

    private void nuevo() {
        limpiarCampos();
        habilitarCampos(true);
        btnGuardar.setEnabled(true);
        modoEdicion = false;
    }

    private void habilitarCampos(boolean estado) {
        txtCodigo.setEnabled(estado);
        txtTitulo.setEnabled(estado);
        txtISBN.setEnabled(estado);
        txtEditorial.setEnabled(estado);
        txtPaginas.setEnabled(estado);
        txtAutores.setEnabled(estado);
    }

    private void guardar() {
        try {
            String codigo = txtCodigo.getText().trim();
            String titulo = txtTitulo.getText().trim();
            String isbn = txtISBN.getText().trim();
            String editorial = txtEditorial.getText().trim();
            int paginas = Integer.parseInt(txtPaginas.getText().trim());

            if (codigo.isEmpty() || titulo.isEmpty()) {
                mostrarError("Complete los campos obligatorios");
                return;
            }

            // Procesar autores
            ListaEnlazada<String> listaAutores = new ListaEnlazada<>();
            String[] codigos = txtAutores.getText().split(",");
            for (String cod : codigos) {
                String codTrim = cod.trim();
                if (!codTrim.isEmpty()) {
                    listaAutores.agregar(codTrim);
                }
            }

            if (modoEdicion) {
                if (sistema.getLibroService().actualizar(codigo, titulo, editorial)) {
                    mostrarExito("Libro actualizado");
                    cargarDatos();
                    configurarEstadoInicial();
                    limpiarCampos();
                }
            } else {
                if (sistema.getLibroService().crear(codigo, titulo, isbn, editorial, paginas, listaAutores)) {
                    mostrarExito("Libro registrado exitosamente");
                    cargarDatos();
                    limpiarCampos();
                } else {
                    mostrarError("El código ya existe");
                }
            }
        } catch (NumberFormatException ex) {
            mostrarError("El número de páginas debe ser un valor numérico");
        }
    }

    private void modificar() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            mostrarError("Seleccione un libro");
            return;
        }

        seleccionarFila();
        txtCodigo.setEnabled(false);
        habilitarCampos(true);
        txtCodigo.setEnabled(false);
        btnGuardar.setEnabled(true);
        modoEdicion = true;
    }

    private void eliminar() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            mostrarError("Seleccione un libro");
            return;
        }

        String codigo = modelo.getValueAt(fila, 0).toString();
        int confirm = JOptionPane.showConfirmDialog(this,
                "¿Eliminar el libro " + codigo + "?",
                "Confirmar", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            // Aquí iría la lógica de eliminación si existiera en el servicio
            mostrarInfo("Funcionalidad de eliminación pendiente");
        }
    }

    private void buscarAvanzado() {
        String termino = txtBuscar.getText().trim();
        if (termino.isEmpty()) {
            cargarDatos();
            return;
        }

        modelo.setRowCount(0);
        String criterio = (String) cboBusqueda.getSelectedItem();
        ListaEnlazada<Libro> resultados = null;

        switch (criterio) {
            case "Título":
                resultados = sistema.getLibroService().buscarPorTitulo(termino);
                break;
            case "ISBN":
                Libro libro = sistema.getLibroService().buscar(termino);
                resultados = new ListaEnlazada<>();
                if (libro != null) resultados.agregar(libro);
                break;
            case "Editorial":
                resultados = sistema.getLibroService().buscarPorEditorial(termino);
                break;
        }

        if (resultados != null && resultados.getSize() > 0) {
            resultados.recorrer(libro ->
                    modelo.addRow(new Object[]{
                            libro.getCodigoLibro(),
                            libro.getTitulo(),
                            libro.getISBN(),
                            libro.getEditorial(),
                            libro.getNumeroPaginas()
                    })
            );
        } else {
            mostrarInfo("No se encontraron resultados");
        }
    }

    private void mostrarAutoresDisponibles() {
        StringBuilder sb = new StringBuilder("AUTORES DISPONIBLES:\n\n");
        sistema.getAutorService().listarTodos().recorrer(autor ->
                sb.append(autor.getCodigoAutor()).append(" - ").append(autor.getNombreAutor()).append("\n")
        );
        JOptionPane.showMessageDialog(this, sb.toString(), "Autores", JOptionPane.INFORMATION_MESSAGE);
    }

    private void seleccionarFila() {
        int fila = tabla.getSelectedRow();
        if (fila >= 0) {
            String codigo = modelo.getValueAt(fila, 0).toString();
            Libro libro = sistema.getLibroService().buscar(codigo);

            if (libro != null) {
                txtCodigo.setText(libro.getCodigoLibro());
                txtTitulo.setText(libro.getTitulo());
                txtISBN.setText(libro.getISBN());
                txtEditorial.setText(libro.getEditorial());
                txtPaginas.setText(String.valueOf(libro.getNumeroPaginas()));

                StringBuilder autores = new StringBuilder();
                libro.getAutores().recorrer(autor -> {
                    if (autores.length() > 0) autores.append(", ");
                    autores.append(autor.getCodigoAutor());
                });
                txtAutores.setText(autores.toString());

                btnModificar.setEnabled(true);
                btnEliminar.setEnabled(true);
            }
        }
    }

    private void cargarDatos() {
        modelo.setRowCount(0);
        sistema.getLibroService().listarTodos().recorrer(libro ->
                modelo.addRow(new Object[]{
                        libro.getCodigoLibro(),
                        libro.getTitulo(),
                        libro.getISBN(),
                        libro.getEditorial(),
                        libro.getNumeroPaginas()
                })
        );
    }

    private void limpiarCampos() {
        txtCodigo.setText("");
        txtTitulo.setText("");
        txtISBN.setText("");
        txtEditorial.setText("");
        txtPaginas.setText("");
        txtAutores.setText("");
        txtBuscar.setText("");
        tabla.clearSelection();
    }

    private JPanel crearPanelTitulo(String texto, Color color) {
        JPanel panel = new JPanel();
        panel.setBackground(color);
        JLabel lbl = new JLabel(texto);
        lbl.setFont(new Font("Arial", Font.BOLD, 20));
        lbl.setForeground(Color.WHITE);
        panel.add(lbl);
        return panel;
    }

    private void mostrarError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void mostrarExito(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }

    private void mostrarInfo(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Información", JOptionPane.INFORMATION_MESSAGE);
    }
}

