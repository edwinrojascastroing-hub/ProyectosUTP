package pe.edu.utp.tp.aplicacion.Pantallas;

import pe.edu.utp.tp.aplicacion.SistemaBiblioteca;
import pe.edu.utp.tp.componentes.EntidadesPrincipales.Ejemplar;
import pe.edu.utp.tp.componentes.EntidadesPrincipales.Prestamo;
import pe.edu.utp.tp.componentes.EntidadesPrincipales.Usuario;
import pe.edu.utp.tp.componentes.ListasEnlazadas.ListaEnlazada;
import pe.edu.utp.tp.componentes.ReglasNegocio.ValidadorPrestamos;
import pe.edu.utp.tp.componentes.Servicios.PrestamoService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;

public class PantallaPrestamos extends JFrame {
    private SistemaBiblioteca sistema;
    private JTable tablaPrestamos, tablaDisponibles;
    private DefaultTableModel modeloPrestamos, modeloDisponibles;
    private JTextField txtUsuario, txtEjemplar, txtBuscarLibro;
    private JTextArea txtResultado;

    public PantallaPrestamos() {
        sistema = SistemaBiblioteca.getInstance();
        configurarVentana();
        crearComponentes();
        cargarDatos();
    }

    private void configurarVentana() {
        setTitle("Gestión de Préstamos");
        setSize(1200, 700);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));
    }

    private void crearComponentes() {
        add(crearPanelTitulo("GESTIÓN DE PRÉSTAMOS", new Color(231, 76, 60)), BorderLayout.NORTH);

        // Panel izquierdo - Formulario
        JPanel panelIzq = new JPanel();
        panelIzq.setLayout(new BoxLayout(panelIzq, BoxLayout.Y_AXIS));
        panelIzq.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelIzq.setPreferredSize(new Dimension(380, 0));

        // Formulario de préstamo
        JPanel panelForm = new JPanel(new GridLayout(3, 2, 5, 10));
        panelForm.setBorder(BorderFactory.createTitledBorder("Nuevo Préstamo"));

        panelForm.add(new JLabel("Código Usuario:"));
        txtUsuario = new JTextField();
        panelForm.add(txtUsuario);

        panelForm.add(new JLabel("Código Ejemplar:"));
        txtEjemplar = new JTextField();
        panelForm.add(txtEjemplar);

        panelIzq.add(panelForm);
        panelIzq.add(Box.createVerticalStrut(10));

        // Botones de acción
        JPanel panelBotones = getJPanel();

        panelIzq.add(panelBotones);
        panelIzq.add(Box.createVerticalStrut(10));

        // Panel de resultado
        JPanel panelResultado = new JPanel(new BorderLayout());
        panelResultado.setBorder(BorderFactory.createTitledBorder("Resultado de Operación"));
        txtResultado = new JTextArea(12, 25);
        txtResultado.setEditable(false);
        txtResultado.setLineWrap(true);
        txtResultado.setWrapStyleWord(true);
        txtResultado.setFont(new Font("Monospaced", Font.PLAIN, 11));
        panelResultado.add(new JScrollPane(txtResultado), BorderLayout.CENTER);
        panelIzq.add(panelResultado);

        add(panelIzq, BorderLayout.WEST);

        // Panel central - Tablas
        JPanel panelCentral = new JPanel(new GridLayout(2, 1, 5, 5));

        // Tabla de préstamos activos
        JPanel panelPrestamos = new JPanel(new BorderLayout());
        panelPrestamos.setBorder(BorderFactory.createTitledBorder("Préstamos Activos"));

        String[] columnasPrestamos = {"Código", "Usuario", "Ejemplar", "F. Préstamo", "F. Devolución", "Días Rest."};
        modeloPrestamos = new DefaultTableModel(columnasPrestamos, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        tablaPrestamos = new JTable(modeloPrestamos);
        panelPrestamos.add(new JScrollPane(tablaPrestamos), BorderLayout.CENTER);

        panelCentral.add(panelPrestamos);

        // Tabla de ejemplares disponibles
        JPanel panelDisponibles = new JPanel(new BorderLayout());
        panelDisponibles.setBorder(BorderFactory.createTitledBorder("Ejemplares Disponibles"));

        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelBusqueda.add(new JLabel("Código Libro:"));
        txtBuscarLibro = new JTextField(15);
        panelBusqueda.add(txtBuscarLibro);
        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.addActionListener(e -> buscarEjemplares());
        panelBusqueda.add(btnBuscar);

        panelDisponibles.add(panelBusqueda, BorderLayout.NORTH);

        String[] columnasDisp = {"Código", "Localización", "Libro", "Estado"};
        modeloDisponibles = new DefaultTableModel(columnasDisp, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        tablaDisponibles = new JTable(modeloDisponibles);
        tablaDisponibles.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int fila = tablaDisponibles.getSelectedRow();
                    if (fila >= 0) {
                        txtEjemplar.setText(modeloDisponibles.getValueAt(fila, 0).toString());
                    }
                }
            }
        });
        panelDisponibles.add(new JScrollPane(tablaDisponibles), BorderLayout.CENTER);

        panelCentral.add(panelDisponibles);

        add(panelCentral, BorderLayout.CENTER);
    }

    private JPanel getJPanel() {
        JPanel panelBotones = new JPanel(new GridLayout(5, 1, 5, 5));
        JButton btnRegistrar = new JButton("✓ Registrar Préstamo");
        JButton btnValidar = new JButton("🔍 Validar Disponibilidad");
        JButton btnListaEspera = new JButton("⏳ Agregar a Lista de Espera");
        JButton btnConsultarEspera = new JButton("📋 Consultar Cola de Espera");
        JButton btnBuscarEjemplares = new JButton("📚 Buscar Ejemplares");

        btnRegistrar.addActionListener(e -> registrarPrestamo());
        btnValidar.addActionListener(e -> validarDisponibilidad());
        btnListaEspera.addActionListener(e -> agregarListaEspera());
        btnConsultarEspera.addActionListener(e -> consultarListaEspera());
        btnBuscarEjemplares.addActionListener(e -> buscarEjemplares());

        panelBotones.add(btnRegistrar);
        panelBotones.add(btnValidar);
        panelBotones.add(btnListaEspera);
        panelBotones.add(btnConsultarEspera);
        panelBotones.add(btnBuscarEjemplares);
        return panelBotones;
    }

    private void registrarPrestamo() {
        String codigoUsuario = txtUsuario.getText().trim();
        String codigoEjemplar = txtEjemplar.getText().trim();

        if (codigoUsuario.isEmpty() || codigoEjemplar.isEmpty()) {
            mostrarResultado("ERROR: Complete todos los campos", false);
            return;
        }

        Usuario usuario = sistema.getUsuarioService().buscar(codigoUsuario);
        Ejemplar ejemplar = sistema.getEjemplarService().buscar(codigoEjemplar);

        if (usuario == null) {
            mostrarResultado("ERROR: Usuario no encontrado\nCódigo: " + codigoUsuario, false);
            return;
        }

        if (ejemplar == null) {
            mostrarResultado("ERROR: Ejemplar no encontrado\nCódigo: " + codigoEjemplar, false);
            return;
        }

        PrestamoService.ResultadoPrestamo resultado =
                sistema.getPrestamoService().registrarPrestamo(usuario, ejemplar);

        if (resultado.isExitoso()) {
            Prestamo p = resultado.getPrestamo();
            StringBuilder sb = new StringBuilder();
            sb.append("═══ PRÉSTAMO REGISTRADO ═══\n\n");
            sb.append("✓ Código Préstamo: ").append(p.getCodigoPrestamo()).append("\n");
            sb.append("Usuario: ").append(usuario.getNombre()).append("\n");
            sb.append("Tipo: ").append(usuario.getTipoUsuario()).append("\n");
            sb.append("Ejemplar: ").append(codigoEjemplar).append("\n");
            sb.append("Fecha préstamo: ").append(p.getFechaPrestamo()).append("\n");
            sb.append("Fecha devolución: ").append(p.getFechaDevolucionEsperada()).append("\n");
            sb.append("Días permitidos: ").append(usuario.getDiasMaximoPrestamo()).append("\n\n");
            sb.append("⚠ Recuerde devolver a tiempo\n");
            sb.append("Multa: S/. 2.00 por día (después de 2 días de gracia)");

            mostrarResultado(sb.toString(), true);
            cargarDatos();
            limpiarCampos();
        } else {
            mostrarResultado("✗ PRÉSTAMO RECHAZADO\n\n" + resultado.getMensaje() +
                    "\n\n💡 Puede agregar el usuario a la lista de espera", false);
        }
    }

    private void validarDisponibilidad() {
        String codigoUsuario = txtUsuario.getText().trim();
        String codigoEjemplar = txtEjemplar.getText().trim();

        if (codigoUsuario.isEmpty() || codigoEjemplar.isEmpty()) {
            mostrarResultado("ERROR: Complete todos los campos", false);
            return;
        }

        Usuario usuario = sistema.getUsuarioService().buscar(codigoUsuario);
        Ejemplar ejemplar = sistema.getEjemplarService().buscar(codigoEjemplar);

        if (usuario == null || ejemplar == null) {
            mostrarResultado("ERROR: Usuario o ejemplar no encontrado", false);
            return;
        }

        // Obtener validación usando el repositorio
        ValidadorPrestamos validador = new ValidadorPrestamos(
                sistema.getPrestamoService().repositorioPrestamos,
                sistema.getEjemplarService().repositorio
        );

        StringBuilder sb = new StringBuilder();
        sb.append("═══ VALIDACIÓN DE PRÉSTAMO ═══\n\n");
        sb.append("Usuario: ").append(usuario.getNombre()).append("\n");
        sb.append("Tipo: ").append(usuario.getTipoUsuario()).append("\n");
        sb.append("Ejemplar: ").append(codigoEjemplar).append("\n");
        sb.append("Estado: ").append(ejemplar.getEstado()).append("\n\n");

        ListaEnlazada<Prestamo> activos = sistema.getPrestamoService()
                .consultarPrestamosActivosPorUsuario(codigoUsuario);
        sb.append("Préstamos activos: ").append(activos.getSize()).append("/3\n\n");



        if (ejemplar.estaDisponible() && activos.getSize() < 3) {
            sb.append("✓ VALIDACIÓN EXITOSA\n");
            sb.append("El préstamo puede realizarse");
        } else {
            sb.append("✗ VALIDACIÓN FALLIDA\n");
            if (!ejemplar.estaDisponible()) {
                sb.append("• Ejemplar no disponible\n");
            }
            if (activos.getSize() >= 3) {
                sb.append("• Usuario alcanzó límite de préstamos\n");
            }
        }

        mostrarResultado(sb.toString(), ejemplar.estaDisponible() && activos.getSize() < 3);
    }

    private void agregarListaEspera() {
        String codigoUsuario = txtUsuario.getText().trim();
        String codigoEjemplar = txtEjemplar.getText().trim();

        if (codigoUsuario.isEmpty() || codigoEjemplar.isEmpty()) {
            mostrarResultado("ERROR: Complete todos los campos", false);
            return;
        }

        if (sistema.getPrestamoService().agregarAListaEspera(codigoEjemplar, codigoUsuario)) {
            int posicion = sistema.getPrestamoService().consultarListaEspera(codigoEjemplar);

            StringBuilder sb = new StringBuilder();
            sb.append("═══ LISTA DE ESPERA ═══\n\n");
            sb.append("✓ Usuario agregado exitosamente\n\n");
            sb.append("Ejemplar: ").append(codigoEjemplar).append("\n");
            sb.append("Usuario: ").append(codigoUsuario).append("\n");
            sb.append("Posición en cola: ").append(posicion).append("\n\n");
            sb.append("🔔 El usuario será notificado cuando\n");
            sb.append("   el ejemplar esté disponible\n\n");
            sb.append("📋 Sistema FIFO (Primero en llegar,\n");
            sb.append("   primero en ser atendido)");

            mostrarResultado(sb.toString(), true);
        } else {
            mostrarResultado("ERROR: El usuario ya está en la lista de espera", false);
        }
    }

    private void consultarListaEspera() {
        String codigoEjemplar = txtEjemplar.getText().trim();

        if (codigoEjemplar.isEmpty()) {
            mostrarResultado("ERROR: Ingrese el código del ejemplar", false);
            return;
        }

        int cantidad = sistema.getPrestamoService().consultarListaEspera(codigoEjemplar);

        StringBuilder sb = new StringBuilder();
        sb.append("═══ COLA DE ESPERA ═══\n\n");
        sb.append("Ejemplar: ").append(codigoEjemplar).append("\n");
        sb.append("Usuarios en espera: ").append(cantidad).append("\n\n");

        if (cantidad == 0) {
            sb.append("✓ No hay usuarios en espera");
        } else {
            sb.append("⏳ Hay ").append(cantidad).append(" usuario(s) esperando\n\n");
            sb.append("La cola se procesará en orden FIFO\n");
            sb.append("cuando el ejemplar sea devuelto");
        }

        mostrarResultado(sb.toString(), true);
    }

    private void buscarEjemplares() {
        String codigoLibro = txtBuscarLibro.getText().trim();

        if (codigoLibro.isEmpty()) {
            mostrarResultado("Ingrese el código del libro", false);
            return;
        }

        modeloDisponibles.setRowCount(0);
        ListaEnlazada<Ejemplar> disponibles = sistema.getEjemplarService().buscarDisponibles(codigoLibro);

        if (disponibles.getSize() == 0) {
            mostrarResultado("No hay ejemplares disponibles para el libro: " + codigoLibro, false);
        } else {
            disponibles.recorrer(ej ->
                    modeloDisponibles.addRow(new Object[]{
                            ej.getCodigoEjemplar(),
                            ej.getLocalizacion(),
                            ej.getCodigoLibro(),
                            ej.getEstado()
                    })
            );

            mostrarResultado("✓ Se encontraron " + disponibles.getSize() +
                    " ejemplar(es) disponible(s)", true);
        }
    }

    private void cargarDatos() {
        modeloPrestamos.setRowCount(0);
        LocalDate hoy = LocalDate.now();

        sistema.getPrestamoService().consultarPrestamosActivos().recorrer(p -> {
            long diasRestantes = java.time.temporal.ChronoUnit.DAYS.between(
                    hoy, p.getFechaDevolucionEsperada()
            );

            modeloPrestamos.addRow(new Object[]{
                    p.getCodigoPrestamo(),
                    p.getCodigoUsuario(),
                    p.getCodigoEjemplar(),
                    p.getFechaPrestamo(),
                    p.getFechaDevolucionEsperada(),
                    diasRestantes
            });
        });
    }

    private void limpiarCampos() {
        txtUsuario.setText("");
        txtEjemplar.setText("");
    }

    private void mostrarResultado(String mensaje, boolean exitoso) {
        txtResultado.setText(mensaje);
        txtResultado.setForeground(exitoso ? new Color(39, 174, 96) : new Color(192, 57, 43));
    }

    private JPanel crearPanelTitulo(String texto, Color color) {
        JPanel panel = new JPanel();
        panel.setBackground(color);
        JLabel lbl = new JLabel(texto);
        lbl.setFont(new Font("Arial", Font.BOLD, 20));
        lbl.setForeground(Color.WHITE);
        panel.add(lbl);
        return panel;
    }
}


