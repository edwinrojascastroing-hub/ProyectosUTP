package pe.edu.utp.tp.aplicacion.Pantallas;

import pe.edu.utp.tp.aplicacion.SistemaBiblioteca;
import pe.edu.utp.tp.componentes.EntidadesPrincipales.Autor;
import pe.edu.utp.tp.componentes.ListasEnlazadas.ListaEnlazada;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PantallaAutores extends JFrame {
    private SistemaBiblioteca sistema;
    private JTable tabla;
    private DefaultTableModel modelo;
    private JTextField txtCodigo, txtNombre, txtBuscar;
    private JButton btnNuevo, btnGuardar, btnModificar, btnEliminar, btnBuscar;
    private boolean modoEdicion = false;

    public PantallaAutores() {
        sistema = SistemaBiblioteca.getInstance();
        configurarVentana();
        crearComponentes();
        cargarDatos();
    }

    private void configurarVentana() {
        setTitle("Gestión de Autores");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));
    }

    private void crearComponentes() {
        // PANEL SUPERIOR - Título
        JPanel panelTitulo = crearPanelTitulo("GESTIÓN DE AUTORES", new Color(52, 152, 219));
        add(panelTitulo, BorderLayout.NORTH);

        // PANEL IZQUIERDO - Formulario
        JPanel panelIzq = new JPanel();
        panelIzq.setLayout(new BoxLayout(panelIzq, BoxLayout.Y_AXIS));
        panelIzq.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelIzq.setPreferredSize(new Dimension(300, 0));

        // Formulario
        JPanel panelForm = new JPanel(new GridLayout(3, 2, 5, 10));
        panelForm.setBorder(BorderFactory.createTitledBorder("Datos del Autor"));

        panelForm.add(new JLabel("Código:"));
        txtCodigo = new JTextField();
        panelForm.add(txtCodigo);

        panelForm.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        panelForm.add(txtNombre);

        panelIzq.add(panelForm);
        panelIzq.add(Box.createVerticalStrut(20));

        // Botones
        JPanel panelBotones = new JPanel(new GridLayout(4, 1, 5, 5));
        btnNuevo = new JButton("Nuevo");
        btnGuardar = new JButton("Guardar");
        btnModificar = new JButton("Modificar");
        btnEliminar = new JButton("Eliminar");

        btnNuevo.addActionListener(e -> nuevo());
        btnGuardar.addActionListener(e -> guardar());
        btnModificar.addActionListener(e -> modificar());
        btnEliminar.addActionListener(e -> eliminar());

        panelBotones.add(btnNuevo);
        panelBotones.add(btnGuardar);
        panelBotones.add(btnModificar);
        panelBotones.add(btnEliminar);

        panelIzq.add(panelBotones);
        add(panelIzq, BorderLayout.WEST);

        // PANEL CENTRAL - Tabla y búsqueda
        JPanel panelCentral = new JPanel(new BorderLayout(5, 5));

        // Búsqueda
        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelBusqueda.add(new JLabel("🔍 Buscar:"));
        txtBuscar = new JTextField(20);
        btnBuscar = new JButton("Buscar");
        JButton btnMostrarTodos = new JButton("Mostrar Todos");

        btnBuscar.addActionListener(e -> buscar());
        btnMostrarTodos.addActionListener(e -> cargarDatos());

        panelBusqueda.add(txtBuscar);
        panelBusqueda.add(btnBuscar);
        panelBusqueda.add(btnMostrarTodos);

        panelCentral.add(panelBusqueda, BorderLayout.NORTH);

        // Tabla
        String[] columnas = {"Código", "Nombre"};
        modelo = new DefaultTableModel(columnas, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        tabla = new JTable(modelo);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) seleccionarFila();
            }
        });

        JScrollPane scroll = new JScrollPane(tabla);
        panelCentral.add(scroll, BorderLayout.CENTER);

        add(panelCentral, BorderLayout.CENTER);

        configurarEstadoInicial();
    }

    private void configurarEstadoInicial() {
        txtCodigo.setEnabled(false);
        txtNombre.setEnabled(false);
        btnGuardar.setEnabled(false);
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
    }

    private void nuevo() {
        limpiarCampos();
        txtCodigo.setEnabled(true);
        txtNombre.setEnabled(true);
        btnGuardar.setEnabled(true);
        modoEdicion = false;
        txtCodigo.requestFocus();
    }

    private void guardar() {
        String codigo = txtCodigo.getText().trim();
        String nombre = txtNombre.getText().trim();

        if (codigo.isEmpty() || nombre.isEmpty()) {
            mostrarError("Complete todos los campos");
            return;
        }

        if (modoEdicion) {
            // Actualizar
            if (sistema.getAutorService().actualizar(codigo, nombre)) {
                mostrarExito("Autor actualizado exitosamente");
                cargarDatos();
                configurarEstadoInicial();
                limpiarCampos();
            } else {
                mostrarError("Error al actualizar el autor");
            }
        } else {
            // Registrar nuevo
            if (sistema.getAutorService().crear(codigo, nombre)) {
                mostrarExito("Autor registrado exitosamente");
                cargarDatos();
                limpiarCampos();
            } else {
                mostrarError("El código ya existe");
            }
        }
    }

    private void modificar() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            mostrarError("Seleccione un autor");
            return;
        }

        seleccionarFila();
        txtCodigo.setEnabled(false);
        txtNombre.setEnabled(true);
        btnGuardar.setEnabled(true);
        modoEdicion = true;
        txtNombre.requestFocus();
    }

    private void eliminar() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            mostrarError("Seleccione un autor");
            return;
        }

        String codigo = modelo.getValueAt(fila, 0).toString();
        int confirm = JOptionPane.showConfirmDialog(this,
                "¿Eliminar el autor " + codigo + "?",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            if (sistema.getAutorService().eliminar(codigo)) {
                mostrarExito("Autor eliminado");
                cargarDatos();
                limpiarCampos();
            } else {
                mostrarError("Error al eliminar");
            }
        }
    }

    private void buscar() {
        String termino = txtBuscar.getText().trim();
        if (termino.isEmpty()) {
            cargarDatos();
            return;
        }

        modelo.setRowCount(0);
        ListaEnlazada<Autor> resultados = sistema.getAutorService().buscarPorNombre(termino);

        if (resultados.getSize() == 0) {
            mostrarInfo("No se encontraron resultados");
        }

        resultados.recorrer(autor ->
                modelo.addRow(new Object[]{autor.getCodigoAutor(), autor.getNombreAutor()})
        );
    }

    private void seleccionarFila() {
        int fila = tabla.getSelectedRow();
        if (fila >= 0) {
            txtCodigo.setText(modelo.getValueAt(fila, 0).toString());
            txtNombre.setText(modelo.getValueAt(fila, 1).toString());
            btnModificar.setEnabled(true);
            btnEliminar.setEnabled(true);
        }
    }

    private void cargarDatos() {
        modelo.setRowCount(0);
        sistema.getAutorService().listarTodos().recorrer(autor ->
                modelo.addRow(new Object[]{autor.getCodigoAutor(), autor.getNombreAutor()})
        );
    }

    private void limpiarCampos() {
        txtCodigo.setText("");
        txtNombre.setText("");
        txtBuscar.setText("");
        tabla.clearSelection();
    }

    private JPanel crearPanelTitulo(String texto, Color color) {
        JPanel panel = new JPanel();
        panel.setBackground(color);
        JLabel lbl = new JLabel(texto);
        lbl.setFont(new Font("Arial", Font.BOLD, 20));
        lbl.setForeground(Color.WHITE);
        panel.add(lbl);
        return panel;
    }

    private void mostrarError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void mostrarExito(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }

    private void mostrarInfo(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Información", JOptionPane.INFORMATION_MESSAGE);
    }
}


