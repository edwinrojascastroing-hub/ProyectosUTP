package pe.edu.utp.tp.aplicacion;


import pe.edu.utp.tp.componentes.Controladores.UsuarioController;
import pe.edu.utp.tp.componentes.ListasEnlazadas.ListaEnlazada;
import pe.edu.utp.tp.componentes.ReglasNegocio.GestorDisponibilidad;
import pe.edu.utp.tp.componentes.Repositorios.*;
import pe.edu.utp.tp.componentes.Servicios.*;

public final class SistemaBiblioteca {

        private static SistemaBiblioteca instancia;

        // Repositorios
    private GestorBiblioteca gestorBiblioteca;

    // Servicios
        private AutorService autorService;
        private LibroService libroService;
        private EjemplarService ejemplarService;
        private UsuarioService usuarioService;
        private PrestamoService prestamoService;


 // controladores
    private UsuarioController usuarioController;



    private SistemaBiblioteca() {
            inicializarRepositorios();
            inicializarServicios();
            inicializarControladores();
            cargarDatosPrueba();
        }

        public static SistemaBiblioteca getInstance() {
            if (instancia == null) {
                instancia = new SistemaBiblioteca();
            }
            return instancia;
        }

        private void inicializarRepositorios() {
       gestorBiblioteca = GestorBiblioteca.getInstance();
        }

        private void inicializarServicios() {
            autorService = new AutorService(gestorBiblioteca.getAutores());
            libroService = new LibroService(gestorBiblioteca.getLibros(), gestorBiblioteca.getAutores());
            ejemplarService = new EjemplarService(gestorBiblioteca.getEjemplares(),
                    new GestorDisponibilidad(gestorBiblioteca.getEjemplares()));
            usuarioService = new UsuarioService(gestorBiblioteca.getUsuarios());
            prestamoService = new PrestamoService(gestorBiblioteca.getPrestamos(), gestorBiblioteca.getEjemplares(), gestorBiblioteca.getUsuarios());

        }

        private void inicializarControladores() {
        usuarioController = new UsuarioController(gestorBiblioteca.getUsuarios());
        }

        private void cargarDatosPrueba() {
            // Autores
      autorService.crear("A001", "Gabriel García Márquez");
            autorService.crear("A002", "Mario Vargas Llosa");
            autorService.crear("A003", "Isabel Allende");

            // Libros
            ListaEnlazada<String> autoresLibro1 = new ListaEnlazada<>();
            autoresLibro1.agregar("A001");
            libroService.crear("L001", "Cien años de soledad", "978-0307474728", "Editorial Sudamericana", 417, autoresLibro1);

            ListaEnlazada<String> autoresLibro2 = new ListaEnlazada<>();
            autoresLibro2.agregar("A002");
            libroService.crear("L002", "La ciudad y los perros", "978-8420412146", "Alfaguara", 408, autoresLibro2);

            // Ejemplares
            ejemplarService.crear("E001", "Estante A-01", "L001");
            ejemplarService.crear("E002", "Estante A-02", "L001");
            ejemplarService.crear("E003", "Estante B-01", "L002");

            // Usuarios
            usuarioService.crearAlumno("U001", "123" ,"Juan Pérez", "Av. Principal 123", "987654321", "5", "A", "EST001");
            usuarioService.crearAdministrativo("U003", "123" ,"Carlos Ruiz","Jr. Terciario 789", "987654323", "Biblioteca", "Bibliotecario");
        }

        // Getters para servicios
    public GestorBiblioteca getGestorBiblioteca() {return gestorBiblioteca;}
        public AutorService getAutorService() { return autorService; }
        public LibroService getLibroService() { return libroService; }
        public EjemplarService getEjemplarService() { return ejemplarService; }
        public UsuarioService getUsuarioService() { return usuarioService; }
        public PrestamoService getPrestamoService() { return prestamoService; }

    public UsuarioController getUsuarioController() { return usuarioController;}


    }

