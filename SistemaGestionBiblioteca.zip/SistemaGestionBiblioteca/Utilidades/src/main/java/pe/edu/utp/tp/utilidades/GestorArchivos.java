package pe.edu.utp.tp.utilidades;

import java.io.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class GestorArchivos {
    private static final String separador = "|";
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public static String[] leerLineas(String nombreArchivo) {
        File archivo = new File(nombreArchivo);
        if (!archivo.exists()) {
            return new String[0]; // Retorna array vacío, NO null
        }

        ArrayList<String> lineas = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(nombreArchivo))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                if (!linea.trim().isEmpty()) {
                    lineas.add(linea);
                }
            }
        } catch (IOException e) {
            System.err.println("Error al leer " + nombreArchivo + ": " + e.getMessage());
        }

        return lineas.toArray(new String[0]);
    }


    public static boolean escribirLineas(String nombreArchivo, String[] lineas) {

        File archivo = new File(nombreArchivo);
        File directorio = archivo.getParentFile();
        if (directorio != null && !directorio.exists()) {
            directorio.mkdirs();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo))) {
            for (String linea : lineas) {
                writer.write(linea);
                writer.newLine();
            }
            return true;
        } catch (IOException e) {
            System.err.println("Error al escribir " + nombreArchivo + ": " + e.getMessage());
            return false;
        }
    }

    public static String[] parsearLinea(String linea) {
        return linea.split("\\" + separador);
    }

    /**
     * Convierte LocalDate a String en formato yyyy-MM-dd
     */
    public static String formatearFecha(LocalDate fecha) {
        return fecha != null ? fecha.format(FORMATTER) : "";
    }

    /**
     * Convierte String a LocalDate desde formato yyyy-MM-dd
     */
    public static LocalDate parsearFecha(String fecha) {
        try {
            return fecha != null && !fecha.isEmpty() ? LocalDate.parse(fecha, FORMATTER) : null;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Verifica si un archivo existe
     */
    public static boolean existe(String nombreArchivo) {
        return new File(nombreArchivo).exists();
    }
}







