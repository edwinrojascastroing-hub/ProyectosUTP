module Componentes {
    exports pe.edu.utp.tp.componentes.EntidadesPrincipales;
    exports pe.edu.utp.tp.componentes.Repositorios;
    exports pe.edu.utp.tp.componentes.ListasEnlazadas;
    exports pe.edu.utp.tp.componentes.Servicios;
    exports pe.edu.utp.tp.componentes.ReglasNegocio;
    exports pe.edu.utp.tp.componentes.GestionColas;
    exports pe.edu.utp.tp.componentes.Controladores;


    requires Utilidades;
    requires java.desktop;


}