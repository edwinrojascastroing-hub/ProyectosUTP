package pe.edu.utp.tp.componentes.Servicios;

import pe.edu.utp.tp.componentes.EntidadesPrincipales.Ejemplar;
import pe.edu.utp.tp.componentes.ListasEnlazadas.ListaEnlazada;
import pe.edu.utp.tp.componentes.ReglasNegocio.GestorDisponibilidad;
import pe.edu.utp.tp.componentes.Repositorios.RepositorioEjemplares;

public class EjemplarService {

        public RepositorioEjemplares repositorio;
        private GestorDisponibilidad gestorDisponibilidad;

        public EjemplarService(RepositorioEjemplares repositorio, GestorDisponibilidad gestor) {
            this.repositorio = repositorio;
            this.gestorDisponibilidad = gestor;
        }

        public boolean crear(String codigo, String localizacion, String codigoLibro) {
            Ejemplar ejemplar = new Ejemplar(codigo, localizacion, codigoLibro);
            return repositorio.agregar(ejemplar);
        }

        public boolean actualizarLocalizacion(String codigo, String nuevaLocalizacion) {
            Ejemplar ejemplar = repositorio.buscarPorCodigo(codigo);
            if (ejemplar != null) {
                ejemplar.setLocalizacion(nuevaLocalizacion);
                return true;
            }
            return false;
        }

        public Ejemplar buscar(String codigo) {
            return repositorio.buscarPorCodigo(codigo);
        }

        public ListaEnlazada<Ejemplar> buscarPorLibro(String codigoLibro) {
            return repositorio.buscarPorLibro(codigoLibro);
        }

        public ListaEnlazada<Ejemplar> buscarDisponibles(String codigoLibro) {
            return repositorio.buscarDisponiblesPorLibro(codigoLibro);
        }

        public int consultarDisponibilidad(String codigoLibro) {
            return gestorDisponibilidad.consultarDisponibilidad(codigoLibro);
        }
    }

