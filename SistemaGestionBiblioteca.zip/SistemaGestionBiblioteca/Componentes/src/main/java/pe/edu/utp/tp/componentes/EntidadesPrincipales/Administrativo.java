package pe.edu.utp.tp.componentes.EntidadesPrincipales;

public class Administrativo extends Usuario {
    private String area;
    private String cargo;

    public Administrativo(String codigo, String password, String nombre, String direccion, String telefono,
                          String area, String cargo) {
        super(codigo, password, nombre, direccion, telefono, TipoUsuario.ADMINISTRATIVO);
        this.area = area;
        this.cargo = cargo;
    }

    public String getArea() { return area; }
    public String getCargo() { return cargo; }

@Override
    public int getDiasMaximoPrestamo() {
        return 10; // Administrativos tienen 10 días
    }

    @Override
    public int getMaximoLibrosSimultaneos() {
        return 5;
    }

    @Override
    public String toString() {
        return "Administrativo{codigo='" + codigoUsuario + "', nombre='" + nombre + "', area='" + area + "'}";
    }
}


