package pe.edu.utp.tp.componentes.EntidadesPrincipales;

public class Alumno extends Usuario {
    private String grado;
    private String seccion;
    private String codigoEstudiante;

    public Alumno(String codigo, String password, String nombre, String direccion, String telefono,
                  String grado, String seccion, String codigoEstudiante) {
        super(codigo, password, nombre, direccion, telefono,  TipoUsuario.ALUMNO);
        this.grado = grado;
        this.seccion = seccion;
        this.codigoEstudiante = codigoEstudiante;
    }



    public String getGrado() { return grado; }
    public String getSeccion() { return seccion; }
    public String getCodigoEstudiante() { return codigoEstudiante; }


    @Override
    public int getDiasMaximoPrestamo() {

        return 3; // Alumnos tienen 3 días
    }

    @Override
    public int getMaximoLibrosSimultaneos() {
        return 2;
    }


    @Override
    public String toString() {
        return "Hola, " + nombre;

    }
}

