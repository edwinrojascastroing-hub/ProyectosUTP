package pe.edu.utp.tp.componentes.GestionColas;

public class Devolucion {
    private String codigoPrestamo;
    private String codigoEjemplar;
    private String codigoUsuario;
    private java.time.LocalDate fechaDevolucion;
    private java.time.LocalDateTime fechaRegistro;

    public Devolucion(String codigoPrestamo, String codigoEjemplar,
                      String codigoUsuario, java.time.LocalDate fechaDevolucion) {
        this.codigoPrestamo = codigoPrestamo;
        this.codigoEjemplar = codigoEjemplar;
        this.codigoUsuario = codigoUsuario;
        this.fechaDevolucion = fechaDevolucion;
        this.fechaRegistro = java.time.LocalDateTime.now();
    }

    public String getCodigoPrestamo() { return codigoPrestamo; }
    public String getCodigoEjemplar() { return codigoEjemplar; }
    public String getCodigoUsuario() { return codigoUsuario; }
    public java.time.LocalDate getFechaDevolucion() { return fechaDevolucion; }
    public java.time.LocalDateTime getFechaRegistro() { return fechaRegistro; }

    @Override
    public String toString() {
        return "Devolucion{prestamo='" + codigoPrestamo + "', usuario='" + codigoUsuario +
                "', fecha=" + fechaDevolucion + "}";
}
}
