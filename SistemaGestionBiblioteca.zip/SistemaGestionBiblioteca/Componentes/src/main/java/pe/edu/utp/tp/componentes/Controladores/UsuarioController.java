package pe.edu.utp.tp.componentes.Controladores;

import pe.edu.utp.tp.componentes.EntidadesPrincipales.Usuario;

import pe.edu.utp.tp.componentes.Repositorios.RepositorioUsuarios;

import javax.swing.*;

public class UsuarioController {
    private RepositorioUsuarios repositorio;


  public UsuarioController ( RepositorioUsuarios repositorio){
      this.repositorio = repositorio;
  }

  public Usuario iniciarSesion(String codigo, String password) {
      JDialog dialogLogin = new JDialog();

      if (codigo == null || password == null) return null;


      Usuario usuario = repositorio.buscarPorCodigo(codigo);

      if (usuario != null && usuario.getPassword().equals(password)) {
          JOptionPane.showMessageDialog(null, "✅ Sesión iniciada:\n"+ "Bievenido: " +usuario.getNombre());

          return usuario;
      }
      JOptionPane.showMessageDialog(dialogLogin,
              "❌ Usuario o contraseña incorrectos " + JOptionPane.ERROR_MESSAGE);



      return null;
  }

  }




