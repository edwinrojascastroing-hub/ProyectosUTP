package pe.edu.utp.tp.componentes.EntidadesPrincipales;

public class Autor {
    private String codigoAutor;
    private String nombreAutor;

    public Autor(String codigoAutor, String nombreAutor) {
        this.codigoAutor = codigoAutor;
        this.nombreAutor = nombreAutor;
    }

    public String getCodigoAutor() {
        return codigoAutor;
    }


    public String getNombreAutor() {
        return nombreAutor;
    }

    public void setNombreAutor(String nombreAutor) {
        this.nombreAutor = nombreAutor;
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Autor)) return false;
        Autor otro = (Autor) obj;
        return codigoAutor.equals(otro.codigoAutor);
    }


    @Override
    public String toString() {
        return "Autor{" +
                "codigoAutor='" + codigoAutor + '\'' +
                ", nombreAutor='" + nombreAutor + '\'' +
                '}';
    }
}
