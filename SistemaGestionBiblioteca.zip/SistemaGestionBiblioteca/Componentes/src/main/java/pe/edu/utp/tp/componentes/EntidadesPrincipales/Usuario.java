package pe.edu.utp.tp.componentes.EntidadesPrincipales;

public abstract class Usuario {
    protected String codigoUsuario;
    protected String password;
    protected String nombre;
    protected String email;
    protected String telefono;
    protected TipoUsuario tipoUsuario;
    private int prestamosActivos;



    public enum TipoUsuario {
         ADMINISTRATIVO,
        DOCENTE,
        ALUMNO
    }

    public Usuario(String codigoUsuario, String password ,String nombre, String email, String telefono, TipoUsuario tipo) {
        this.codigoUsuario = codigoUsuario;
        this.password = password;
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
        this.prestamosActivos = 0;
        this.tipoUsuario = tipo;
    }

    public String getCodigoUsuario() {
        return codigoUsuario;
    }

    public void setCodigoUsuario(String codigoUsuario) {
        this.codigoUsuario = codigoUsuario;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public TipoUsuario getTipoUsuario() {
        return tipoUsuario;
    }

    public boolean puedePrestar() {
        return prestamosActivos < getMaximoLibrosSimultaneos();
    }

    public void incrementarPrestamos() {
        prestamosActivos++;
    }

    public void disminuirPrestamos() {
        if (prestamosActivos > 0)
            prestamosActivos--;
    }

    public int getPrestamosActivos() {
        return prestamosActivos;
    }


    public abstract int getDiasMaximoPrestamo();


    public abstract int getMaximoLibrosSimultaneos();









    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Usuario)) return false;
        Usuario otro = (Usuario) obj;
        return codigoUsuario.equals(otro.codigoUsuario);
    }



}



