package pe.edu.utp.tp.componentes.EntidadesPrincipales;

import java.time.LocalDate;

public class Prestamo {
    private String codigoPrestamo;
    private String codigoUsuario;
    private String codigoEjemplar;
    private java.time.LocalDate fechaPrestamo;
    private java.time.LocalDate fechaDevolucionEsperada;
    private java.time.LocalDate fechaDevolucionReal;
    private boolean tieneMulta;
    private double montoMulta;
    private String observaciones;



    public Prestamo(String codigoPrestamo, String codigoUsuario, String codigoEjemplar,
                    java.time.LocalDate fechaPrestamo, java.time.LocalDate fechaDevolucionEsperada) {
        this.codigoPrestamo = codigoPrestamo;
        this.codigoUsuario = codigoUsuario;
        this.codigoEjemplar = codigoEjemplar;
        this.fechaPrestamo = fechaPrestamo;
        this.fechaDevolucionEsperada = fechaDevolucionEsperada;
        this.fechaDevolucionReal = null;
        this.tieneMulta = false;
        this.montoMulta = 0.0;
    }

    public String getCodigoPrestamo() { return codigoPrestamo; }
    public String getCodigoUsuario() { return codigoUsuario; }
    public String getCodigoEjemplar() { return codigoEjemplar; }
    public java.time.LocalDate getFechaPrestamo() { return fechaPrestamo; }
    public java.time.LocalDate getFechaDevolucionEsperada() { return fechaDevolucionEsperada; }
    public java.time.LocalDate getFechaDevolucionReal() { return fechaDevolucionReal; }
    public boolean isTieneMulta() { return tieneMulta; }
    public double getMontoMulta() { return montoMulta; }

    public void setFechaDevolucionReal(java.time.LocalDate fecha) { this.fechaDevolucionReal = fecha; }
    public void setTieneMulta(boolean tieneMulta) { this.tieneMulta = tieneMulta; }
    public void setMontoMulta(double montoMulta) { this.montoMulta = montoMulta; }



    public void setCodigoUsuario(String codigoUsuario) {
        this.codigoUsuario = codigoUsuario;
    }

    public void setCodigoEjemplar(String codigoEjemplar) {
        this.codigoEjemplar = codigoEjemplar;
    }

    public void setFechaPrestamo(LocalDate fechaPrestamo) {
        this.fechaPrestamo = fechaPrestamo;
    }

    public void setFechaDevolucionEsperada(LocalDate fechaDevolucionEsperada) {
        this.fechaDevolucionEsperada = fechaDevolucionEsperada;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public boolean estaActivo() {
        return fechaDevolucionReal == null;
    }

    @Override
    public String toString() {
        return "Prestamo{" +
                "codigoPrestamo='" + codigoPrestamo + '\'' +
                ", codigoUsuario='" + codigoUsuario + '\'' +
                ", codigoEjemplar='" + codigoEjemplar + '\'' +
                ", fechaPrestamo=" + fechaPrestamo +
                ", fechaDevolucionEsperada=" + fechaDevolucionEsperada +
                ", fechaDevolucionReal=" + fechaDevolucionReal +
                ", tieneMulta=" + tieneMulta +
                ", montoMulta=" + montoMulta +
                ", observaciones='" + observaciones + '\'' +
                '}';
    }
}
