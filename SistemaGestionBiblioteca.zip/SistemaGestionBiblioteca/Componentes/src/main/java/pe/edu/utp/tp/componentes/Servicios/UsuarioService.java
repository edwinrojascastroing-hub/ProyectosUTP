package pe.edu.utp.tp.componentes.Servicios;

import pe.edu.utp.tp.componentes.EntidadesPrincipales.Administrativo;
import pe.edu.utp.tp.componentes.EntidadesPrincipales.Alumno;
import pe.edu.utp.tp.componentes.EntidadesPrincipales.Docente;
import pe.edu.utp.tp.componentes.EntidadesPrincipales.Usuario;
import pe.edu.utp.tp.componentes.ListasEnlazadas.ListaEnlazada;
import pe.edu.utp.tp.componentes.Repositorios.RepositorioUsuarios;

public class UsuarioService {

        private RepositorioUsuarios repositorio;

        public UsuarioService(RepositorioUsuarios repositorio) {
            this.repositorio = repositorio;
        }

        public boolean crearDocente(String codigo, String password, String nombre, String direccion,
                                    String telefono, String departamento, String especialidad) {
            Usuario docente = new Docente(codigo, password,  nombre, direccion, telefono, departamento, especialidad);
            return repositorio.agregar(docente);
        }

        public boolean crearAdministrativo(String codigo, String password,  String nombre, String direccion,
                                           String telefono, String area, String cargo) {
            Usuario admin = new Administrativo(codigo, password, nombre, direccion, telefono, area, cargo);
            return repositorio.agregar(admin);
        }

        public boolean crearAlumno(String codigo, String password ,String nombre, String direccion,
                                   String telefono, String grado, String seccion, String codigoEstudiante) {
            Usuario alumno = new Alumno(codigo,password,  nombre, direccion, telefono, grado, seccion, codigoEstudiante);
            return repositorio.agregar(alumno);
        }

        public Usuario buscar(String codigo) {
            return repositorio.buscarPorCodigo(codigo);
        }

        public ListaEnlazada<Usuario> buscarPorNombre(String nombre) {
            return repositorio.buscarPorNombre(nombre);
        }

        public ListaEnlazada<Usuario> buscarPorTipo(Usuario.TipoUsuario tipo) {
            return repositorio.buscarPorTipo(tipo);
        }

        public ListaEnlazada<Usuario> listarTodos() {
            return repositorio.obtenerTodos();
        }
    }

