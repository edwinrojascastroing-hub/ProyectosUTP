package pe.edu.utp.tp.componentes.GestionColas;

public class SolicitudEspera {
        private String codigoUsuario;
        private String codigoEjemplar;
        private java.time.LocalDateTime fechaSolicitud;

        public SolicitudEspera(String codigoUsuario, String codigoEjemplar) {
            this.codigoUsuario = codigoUsuario;
            this.codigoEjemplar = codigoEjemplar;
            this.fechaSolicitud = java.time.LocalDateTime.now();
        }

        public String getCodigoUsuario() { return codigoUsuario; }
        public String getCodigoEjemplar() { return codigoEjemplar; }
        public java.time.LocalDateTime getFechaSolicitud() { return fechaSolicitud; }

        @Override
        public String toString() {
            return "SolicitudEspera{usuario='" + codigoUsuario + "', ejemplar='" + codigoEjemplar +
                    "', fecha=" + fechaSolicitud + "}";
        }
    }

