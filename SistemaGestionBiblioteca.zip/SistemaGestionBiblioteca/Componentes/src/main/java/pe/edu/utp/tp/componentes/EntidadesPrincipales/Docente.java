package pe.edu.utp.tp.componentes.EntidadesPrincipales;

public class Docente extends Usuario {
    private String departamento;
    private String especialidad;

    public Docente(String codigo, String password,  String nombre, String direccion, String telefono,
                   String departamento, String especialidad) {
        super(codigo, password, nombre, direccion, telefono, TipoUsuario.DOCENTE);
        this.departamento = departamento;
        this.especialidad = especialidad;
    }

    public String getDepartamento() { return departamento; }
    public String getEspecialidad() { return especialidad; }

    @Override
    public int getDiasMaximoPrestamo() {
        return 10; // Docentes tienen 30 días
    }

    @Override
    public int getMaximoLibrosSimultaneos() {
        return 5; // Docentes pueden llevar hasta 5 libros
    }

    @Override
    public String toString() {
        return "Docente{codigo='" + codigoUsuario + "', nombre='" + nombre + "', depto='" + departamento + "'}";
    }
}

