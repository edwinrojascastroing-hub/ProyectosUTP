package pe.edu.utp.tp.componentes.ReglasNegocio;

import pe.edu.utp.tp.componentes.EntidadesPrincipales.Usuario;
import pe.edu.utp.tp.componentes.Repositorios.RepositorioUsuarios;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class CalculadorMultas {
    private static final double multaPorDia= 1.5;
    private Usuario usuario;
    private  int diasGracia;

    public CalculadorMultas() {

    }

    public CalculadorMultas(Usuario usuario) {
        this.usuario = usuario;
        this.diasGracia = usuario.getDiasMaximoPrestamo();
    }



    public int calcularDiasRetraso(LocalDate fechaEsperada, LocalDate fechaReal){
        Long dias = ChronoUnit.DAYS.between(fechaEsperada, fechaReal);
        return (int) Math.max(0, dias);
    }


    public boolean tieneMulta(int diasRetraso){
        return (diasRetraso > diasGracia);
    }

    public double CalcularMontoMulta(int diasRetraso){
        if(!tieneMulta(diasRetraso)){
            return 0.0;
        }

        int diasMultados = diasRetraso - diasGracia;
        return diasMultados * multaPorDia;
    }


     public ResultadoMulta calcular(LocalDate fechaEsperada, LocalDate fechaReal){
            int dias = calcularDiasRetraso(fechaEsperada, fechaReal);
            boolean tiene = tieneMulta(dias);
            double monto = CalcularMontoMulta(dias);
         return new ResultadoMulta(dias, tiene, monto);
     }

    public static class ResultadoMulta {
        private int diasRetraso;
        private boolean tieneMulta;
        private double monto;

        public ResultadoMulta(int diasRetraso, boolean tieneMulta, double monto) {
            this.diasRetraso = diasRetraso;
            this.tieneMulta = tieneMulta;
            this.monto = monto;
        }

        public int getDiasRetraso() { return diasRetraso; }
        public boolean isTieneMulta() { return tieneMulta; }
        public double getMonto() { return monto; }

        @Override
        public String toString() {
            return "Retraso: " + diasRetraso + " días, Multa: S/. " + monto;
        }
    }



}

