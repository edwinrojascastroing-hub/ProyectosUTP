package pe.edu.utp.tp.componentes.Servicios;

import pe.edu.utp.tp.componentes.EntidadesPrincipales.Ejemplar;
import pe.edu.utp.tp.componentes.EntidadesPrincipales.Prestamo;
import pe.edu.utp.tp.componentes.EntidadesPrincipales.Usuario;
import pe.edu.utp.tp.componentes.GestionColas.ColaDevoluciones;
import pe.edu.utp.tp.componentes.GestionColas.GestorListaEspera;
import pe.edu.utp.tp.componentes.ListasEnlazadas.ListaEnlazada;
import pe.edu.utp.tp.componentes.ReglasNegocio.CalculadorMultas;
import pe.edu.utp.tp.componentes.ReglasNegocio.GestorDisponibilidad;
import pe.edu.utp.tp.componentes.ReglasNegocio.ValidadorPrestamos;
import pe.edu.utp.tp.componentes.Repositorios.RepositorioEjemplares;
import pe.edu.utp.tp.componentes.Repositorios.RepositorioPrestamos;
import pe.edu.utp.tp.componentes.Repositorios.RepositorioUsuarios;

public class PrestamoService {
    public RepositorioPrestamos repositorioPrestamos;
    private ValidadorPrestamos validador;
    private GestorDisponibilidad gestorDisponibilidad;
    private CalculadorMultas calculadorMultas;
    private GestorListaEspera gestorListaEspera;
    private ColaDevoluciones colaDevoluciones;
    private int contadorPrestamos;



    public PrestamoService(RepositorioPrestamos repoPrestamos,
                           RepositorioEjemplares repoEjemplares,
                           RepositorioUsuarios repoUsuarios) {
        this.repositorioPrestamos = repoPrestamos;
        this.gestorDisponibilidad = new GestorDisponibilidad(repoEjemplares);
        this.validador = new ValidadorPrestamos(repoPrestamos, repoEjemplares);
        this.calculadorMultas = new CalculadorMultas();
        this.gestorListaEspera = new GestorListaEspera();
        this.colaDevoluciones = new ColaDevoluciones();
        this.contadorPrestamos = 1;
    }

    public ResultadoPrestamo registrarPrestamo(Usuario usuario, Ejemplar ejemplar) {
        // Validar el préstamo
        ValidadorPrestamos.ResultadoValidacion validacion =  validador.validarPrestamo(usuario, ejemplar);

        if (!validacion.isEsValido()) {
            return new ResultadoPrestamo(false, validacion.getMensaje(), null);
        }

        // Calcular fecha de devolución esperada
        java.time.LocalDate fechaPrestamo = java.time.LocalDate.now();
        java.time.LocalDate fechaDevolucion = fechaPrestamo.plusDays(usuario.getDiasMaximoPrestamo());

        // Crear préstamo
        String codigoPrestamo = "P" + String.format("%05d", contadorPrestamos++);
        Prestamo prestamo = new Prestamo(codigoPrestamo, usuario.getCodigoUsuario(),
                ejemplar.getCodigoEjemplar(), fechaPrestamo, fechaDevolucion);

        // Registrar y actualizar disponibilidad
        if (repositorioPrestamos.agregar(prestamo)) {
            gestorDisponibilidad.marcarComoPrestado(ejemplar.getCodigoEjemplar());

            return new ResultadoPrestamo(true, "Préstamo registrado exitosamente", prestamo);
        }

        return new ResultadoPrestamo(false, "Error al registrar el préstamo", null);
    }

    public ResultadoDevolucion registrarDevolucion(String codigoPrestamo) {
        Prestamo prestamo = repositorioPrestamos.buscarPorCodigo(codigoPrestamo);

        if (prestamo == null) {
            return new ResultadoDevolucion(false, "Préstamo no encontrado", null);
        }

        if (!prestamo.estaActivo()) {
            return new ResultadoDevolucion(false, "Este préstamo ya fue devuelto", null);
        }

        // Registrar fecha de devolución
        java.time.LocalDate fechaDevolucion = java.time.LocalDate.now();
        prestamo.setFechaDevolucionReal(fechaDevolucion);

        // Calcular multa si hay retraso
        CalculadorMultas.ResultadoMulta resultadoMulta =
                calculadorMultas.calcular(prestamo.getFechaDevolucionEsperada(), fechaDevolucion);

        prestamo.setTieneMulta(resultadoMulta.isTieneMulta());
        prestamo.setMontoMulta(resultadoMulta.getMonto());

        // Marcar ejemplar como disponible
        gestorDisponibilidad.marcarComoDisponible(prestamo.getCodigoEjemplar());

        // Verificar si hay usuarios en lista de espera
        String siguienteUsuario = gestorListaEspera.obtenerSiguienteEnEspera(prestamo.getCodigoEjemplar());

        String mensaje = "Devolución registrada exitosamente. " + resultadoMulta.toString();
        if (siguienteUsuario != null) {
            mensaje += ". Usuario en espera: " + siguienteUsuario;
        }

        return new ResultadoDevolucion(true, mensaje, resultadoMulta);
    }

    public boolean agregarAListaEspera(String codigoEjemplar, String codigoUsuario) {
        return gestorListaEspera.agregarAEspera(codigoEjemplar, codigoUsuario);
    }

    public int consultarListaEspera(String codigoEjemplar) {
        return gestorListaEspera.cantidadEnEspera(codigoEjemplar);
    }

    public ListaEnlazada<Prestamo> consultarPrestamosActivos() {
        return repositorioPrestamos.buscarActivos();
    }

    public ListaEnlazada<Prestamo> consultarPrestamosPorUsuario(String codigoUsuario) {
        return repositorioPrestamos.buscarPorUsuario(codigoUsuario);
    }

    public ListaEnlazada<Prestamo> consultarPrestamosActivosPorUsuario(String codigoUsuario) {
        return repositorioPrestamos.buscarActivosPorUsuario(codigoUsuario);
    }

    // Clases de resultado
    public static class ResultadoPrestamo {
        private boolean exitoso;
        private String mensaje;
        private Prestamo prestamo;

        public ResultadoPrestamo(boolean exitoso, String mensaje, Prestamo prestamo) {
            this.exitoso = exitoso;
            this.mensaje = mensaje;
            this.prestamo = prestamo;
        }

        public boolean isExitoso() { return exitoso; }
        public String getMensaje() { return mensaje; }
        public Prestamo getPrestamo() { return prestamo; }
    }

    public static class ResultadoDevolucion {
        private boolean exitoso;
        private String mensaje;
        private CalculadorMultas.ResultadoMulta multa;

        public ResultadoDevolucion(boolean exitoso, String mensaje, CalculadorMultas.ResultadoMulta multa) {
            this.exitoso = exitoso;
            this.mensaje = mensaje;
            this.multa = multa;
        }

        public boolean isExitoso() { return exitoso; }
        public String getMensaje() { return mensaje; }
        public CalculadorMultas.ResultadoMulta getMulta() { return multa; }
    }
}

