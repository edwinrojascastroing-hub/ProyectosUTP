package pe.edu.utp.tp.componentes.GestionColas;

import pe.edu.utp.tp.componentes.ListasEnlazadas.Cola;

public class ColaDevoluciones {
    private Cola<Devolucion> cola;

    public ColaDevoluciones() {
        this.cola = new Cola<>();
    }

    public void registrarDevolucion(String codigoPrestamo, String codigoEjemplar,
                                    String codigoUsuario, java.time.LocalDate fechaDevolucion) {
        Devolucion dev = new Devolucion(codigoPrestamo, codigoEjemplar, codigoUsuario, fechaDevolucion);
        cola.encolar(dev);
    }

    public Devolucion procesarSiguiente() {
        if (cola.estaVacia()) {
            return null;
        }
        return cola.desencolar();
    }

    public Devolucion verSiguiente() {
        if (cola.estaVacia()) {
            return null;
        }
        return cola.verFrente();
    }

    public int cantidadPendientes() {
        return cola.getSize();
    }

    public boolean hayPendientes() {
        return !cola.estaVacia();
    }
}

