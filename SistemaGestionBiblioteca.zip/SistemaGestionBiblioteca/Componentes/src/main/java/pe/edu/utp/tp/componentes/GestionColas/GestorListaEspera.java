package pe.edu.utp.tp.componentes.GestionColas;

import pe.edu.utp.tp.componentes.ListasEnlazadas.Cola;
import pe.edu.utp.tp.componentes.ListasEnlazadas.ListaEnlazada;

public class GestorListaEspera {
    private ListaEnlazada<EntradaColaEspera> colasEspera;

    // Cola de solicitudes pendientes por cada ejemplar
    public GestorListaEspera() {
        this.colasEspera = new ListaEnlazada<>();
    }

    // Agregar usuario a la lista de espera de un ejemplar
    public boolean agregarAEspera(String codigoEjemplar, String codigoUsuario) {
        EntradaColaEspera entrada = buscarColaEjemplar(codigoEjemplar);

        if (entrada == null) {
            // Crear nueva cola para este ejemplar
            entrada = new EntradaColaEspera(codigoEjemplar);
            colasEspera.agregar(entrada);
        }

        // Verificar que el usuario no esté ya en la cola
        if (entrada.contieneUsuario(codigoUsuario)) {
            return false;
        }

        entrada.getCola().encolar(new SolicitudEspera(codigoUsuario, codigoEjemplar));
        return true;
    }
    // Obtener el siguiente usuario en espera para un ejemplar
    public String obtenerSiguienteEnEspera(String codigoEjemplar) {
        EntradaColaEspera entrada = buscarColaEjemplar(codigoEjemplar);

        if (entrada == null || entrada.getCola().estaVacia()) {
            return null;
        }

        SolicitudEspera solicitud = entrada.getCola().desencolar();
        return solicitud.getCodigoUsuario();
    }

    // Ver quién es el siguiente sin sacarlo de la cola
    public String verSiguienteEnEspera(String codigoEjemplar) {
        EntradaColaEspera entrada = buscarColaEjemplar(codigoEjemplar);

        if (entrada == null || entrada.getCola().estaVacia()) {
            return null;
        }

        SolicitudEspera solicitud = entrada.getCola().verFrente();
        return solicitud.getCodigoUsuario();
    }

    // Obtener cantidad de personas en espera
    public int cantidadEnEspera(String codigoEjemplar) {
        EntradaColaEspera entrada = buscarColaEjemplar(codigoEjemplar);
        return (entrada != null) ? entrada.getCola().getSize() : 0;
    }

    // Cancelar solicitud de un usuario
    public boolean cancelarEspera(String codigoEjemplar, String codigoUsuario) {
        EntradaColaEspera entrada = buscarColaEjemplar(codigoEjemplar);

        if (entrada == null) {
            return false;
        }

        return entrada.eliminarUsuario(codigoUsuario);
    }

    private EntradaColaEspera buscarColaEjemplar(String codigoEjemplar) {
        return colasEspera.buscar(e -> e.getCodigoEjemplar().equals(codigoEjemplar));
    }


    private static class EntradaColaEspera {
        private String codigoEjemplar;
        private Cola<SolicitudEspera> cola;

        public EntradaColaEspera(String codigoEjemplar) {
            this.codigoEjemplar = codigoEjemplar;
            this.cola = new Cola<>();
        }

        public String getCodigoEjemplar() {
            return codigoEjemplar;
        }

        public Cola<SolicitudEspera> getCola() {
            return cola;
        }

        public boolean contieneUsuario(String codigoUsuario) {
            // Verificar si el usuario ya está en la cola
            Cola<SolicitudEspera> colaTemp = new Cola<>();
            boolean encontrado = false;

            while (!cola.estaVacia()) {
                SolicitudEspera sol = cola.desencolar();
                if (sol.getCodigoUsuario().equals(codigoUsuario)) {
                    encontrado = true;
                }
                colaTemp.encolar(sol);
            }

            // Restaurar la cola original
            while (!colaTemp.estaVacia()) {
                cola.encolar(colaTemp.desencolar());
            }

            return encontrado;
        }

        public boolean eliminarUsuario(String codigoUsuario) {
            Cola<SolicitudEspera> colaTemp = new Cola<>();
            boolean eliminado = false;

            while (!cola.estaVacia()) {
                SolicitudEspera sol = cola.desencolar();
                if (!sol.getCodigoUsuario().equals(codigoUsuario)) {
                    colaTemp.encolar(sol);
                } else {
                    eliminado = true;
                }
            }

            // Restaurar la cola sin el usuario eliminado
            while (!colaTemp.estaVacia()) {
                cola.encolar(colaTemp.desencolar());
            }

            return eliminado;
        }
    }


}

