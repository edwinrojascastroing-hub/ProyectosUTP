package pe.edu.utp.tp.componentes.Repositorios;

import pe.edu.utp.tp.componentes.EntidadesPrincipales.Administrativo;
import pe.edu.utp.tp.componentes.EntidadesPrincipales.Alumno;
import pe.edu.utp.tp.componentes.EntidadesPrincipales.Usuario;
import pe.edu.utp.tp.componentes.ListasEnlazadas.ListaEnlazada;
import pe.edu.utp.tp.componentes.ListasEnlazadas.Nodo;
import pe.edu.utp.tp.utilidades.GestorArchivos;

import java.util.ArrayList;

public class RepositorioUsuarios {
    private ListaEnlazada<Usuario> usuarios;
    private String nombreArchivo;

    public RepositorioUsuarios(String nombreArchivo) {
        this.usuarios = new ListaEnlazada<>();
        this.nombreArchivo = nombreArchivo;
        cargarDesdeArchivo();
    }

    public boolean agregar(Usuario usuario) {
        if (buscarPorCodigo(usuario.getCodigoUsuario()) != null) {
            return false;
        }
        usuarios.agregar(usuario);
        guardarEnArchivo();
        return true;
    }

    public Usuario buscarPorCodigo(String codigo) {
        return usuarios.buscar(u -> u.getCodigoUsuario().equals(codigo));
    }

    public ListaEnlazada<Usuario> buscarPorNombre(String nombre) {
        return usuarios.filtrar(u -> u.getNombre().toLowerCase().contains(nombre.toLowerCase()));
    }

    public ListaEnlazada<Usuario> buscarPorTipo(Usuario.TipoUsuario tipo) {
        return usuarios.filtrar(u -> u.getTipoUsuario() == tipo);
    }

    public ListaEnlazada<Usuario> obtenerTodos() {
        return usuarios;
    }

    private void guardarEnArchivo() {
        ArrayList<String> lineas = new ArrayList<>();
        Nodo<Usuario> actual = usuarios.getCabeza();

        while (actual != null) {
            Usuario u = actual.getDato();
            String linea = String.format("%s|%s|%s|%s|%s|%s",
                    u.getCodigoUsuario(),u.getPassword(),u.getNombre(), u.getEmail(),
                    u.getTelefono(), u.getTipoUsuario().name()
            );
            lineas.add(linea);
            actual = actual.getSiguiente();
        }
        GestorArchivos.escribirLineas(nombreArchivo, lineas.toArray(new String[0]));
    }


    private void cargarDesdeArchivo() {
        String[] lineas = GestorArchivos.leerLineas(nombreArchivo);

        for (String linea : lineas) {
            String[] datos = linea.split("\\|"); // Separar por "|"

            if (datos.length < 5) continue; // Línea inválida

            Usuario.TipoUsuario tipo = Usuario.TipoUsuario.valueOf(datos[5]);
            Usuario usuario = null;

            switch (tipo) {
                case ALUMNO -> {
                    // datos[5] = carrera, datos[6] = ciclo
                    if (datos.length >= 8) {
                        usuario = new Alumno(datos[0], datos[1], datos[2], datos[3],
                                datos[5], datos[6], datos[7],  datos[8] );
                    }
                }
                case ADMINISTRATIVO -> {
                    // datos[5] = área, datos[6] = cargo
                    if (datos.length >= 8) {
                        usuario = new Administrativo(datos[0], datos[1], datos[2], datos[3],
                                datos[5], datos[6], datos[7]);
                    }
                }
            }

            if (usuario != null) {
                usuarios.agregar(usuario);
            }
        }

    }


}

