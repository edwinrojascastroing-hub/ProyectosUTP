package pe.edu.utp.tp.componentes.EntidadesPrincipales;

import pe.edu.utp.tp.componentes.ListasEnlazadas.ListaEnlazada;

public class Libro {
    private String codigoLibro;
    private String titulo;
    private String ISBN;
    private String editorial;
    private int numeroPaginas;
    private ListaEnlazada<Autor> autores;


    public Libro(String codigoLibro, String titulo, String ISBN, String editorial, int numeroPaginas) {
        this.codigoLibro = codigoLibro;
        this.titulo = titulo;
        this.ISBN = ISBN;
        this.editorial = editorial;
        this.numeroPaginas = numeroPaginas;
        this.autores = new ListaEnlazada<>();
    }


    public void agregarAutor(Autor autor) {
        autores.agregar(autor);
    }


    public String getCodigoLibro() {
        return codigoLibro;
    }

    public void setCodigoLibro(String codigoLibro) {
        this.codigoLibro = codigoLibro;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    public int getNumeroPaginas() {
        return numeroPaginas;
    }

    public void setNumeroPaginas(int numeroPaginas) {
        this.numeroPaginas = numeroPaginas;
    }

    public ListaEnlazada<Autor> getAutores() {
        return autores;
    }

    public void setAutores(ListaEnlazada<Autor> autores) {
        this.autores = autores;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Libro)) return false;
        Libro otro = (Libro) obj;
        return codigoLibro.equals(otro.codigoLibro);
    }


    @Override
    public String toString() {
        return "Libro{" +
                "codigoLibro='" + codigoLibro + '\'' +
                ", titulo='" + titulo + '\'' +
                ", ISBN='" + ISBN + '\'' +
                ", editorial='" + editorial + '\'' +
                ", numeroPaginas=" + numeroPaginas +
                ", autores=" + autores +
                '}';
    }
}
