package pe.edu.utp.tp.componentes.ReglasNegocio;

import pe.edu.utp.tp.componentes.EntidadesPrincipales.Ejemplar;
import pe.edu.utp.tp.componentes.EntidadesPrincipales.Prestamo;
import pe.edu.utp.tp.componentes.EntidadesPrincipales.Usuario;
import pe.edu.utp.tp.componentes.ListasEnlazadas.ListaEnlazada;
import pe.edu.utp.tp.componentes.Repositorios.RepositorioEjemplares;
import pe.edu.utp.tp.componentes.Repositorios.RepositorioPrestamos;

public class ValidadorPrestamos {
    private RepositorioPrestamos repositorioPrestamos;
    private RepositorioEjemplares repositorioEjemplares;

    public ValidadorPrestamos(RepositorioPrestamos repoPrestamos, RepositorioEjemplares repoEjemplares) {
        this.repositorioPrestamos = repoPrestamos;
        this.repositorioEjemplares = repoEjemplares;
    }

    public ResultadoValidacion validarPrestamo(Usuario usuario, Ejemplar ejemplar) {
        // Verificar disponibilidad del ejemplar

        if (!ejemplar.estaDisponible()) {
            return new ResultadoValidacion(false, "El ejemplar no está disponible");
        }

        // Verificar si el usuario tiene multas pendientes
        if (usuarioTieneMultasPendientes(usuario.getCodigoUsuario())) {
            return new ResultadoValidacion(false, "El usuario tiene multas pendientes");
        }

        // Verificar límite de préstamos activos (máximo 3)
        int limiteLibro = usuario.getMaximoLibrosSimultaneos();
        ListaEnlazada<Prestamo> prestamosActivos =
                repositorioPrestamos.buscarActivosPorUsuario(usuario.getCodigoUsuario());
        if (prestamosActivos.getSize() >= limiteLibro) {


            return new ResultadoValidacion(false, "El usuario ha alcanzado el límite de préstamos activos");
        }

        return new ResultadoValidacion(true, "Préstamo válido");
    }

    private boolean usuarioTieneMultasPendientes(String codigoUsuario) {
        ListaEnlazada<Prestamo> prestamos = repositorioPrestamos.buscarPorUsuario(codigoUsuario);
        final boolean[] tieneMultas = {false};

        prestamos.recorrer(p -> {
            if (p.isTieneMulta() && p.getMontoMulta() > 0) {
                tieneMultas[0] = true;
            }
        });

        return tieneMultas[0];
    }

    public static class ResultadoValidacion {
        private boolean esValido;
        private String mensaje;

        public ResultadoValidacion(boolean esValido, String mensaje) {
            this.esValido = esValido;
            this.mensaje = mensaje;
        }

        public boolean isEsValido() { return esValido; }
        public String getMensaje() { return mensaje; }
    }
}


