package pe.edu.utp.tp.componentes.Repositorios;

import pe.edu.utp.tp.componentes.EntidadesPrincipales.Autor;
import pe.edu.utp.tp.componentes.EntidadesPrincipales.Libro;
import pe.edu.utp.tp.componentes.ListasEnlazadas.ListaEnlazada;
import pe.edu.utp.tp.componentes.ListasEnlazadas.Nodo;
import pe.edu.utp.tp.utilidades.GestorArchivos;

import java.util.ArrayList;



public class RepositorioLibros {
    private ListaEnlazada<Libro> libros;
    private String nombreArchivo;
    private RepositorioAutores repoAutores;

    public RepositorioLibros(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
        this.libros = new ListaEnlazada<>();
        cargarDesdeArchivo();
    }


    public boolean agregar(Libro libro) {
        if (buscarPorCodigo(libro.getCodigoLibro()) != null) {
            return false;
        }
        libros.agregar(libro);
        guardarEnArchivo();
        return true;
    }

    public Libro buscarPorCodigo(String codigo) {
        return libros.buscar(l -> l.getCodigoLibro().equals(codigo));
    }

    public Libro buscarPorIsbn(String isbn) {
        return libros.buscar(l -> l.getISBN().equals(isbn));
    }

    public ListaEnlazada<Libro> buscarPorTitulo(String titulo) {
        return libros.filtrar(l -> l.getTitulo().toLowerCase().contains(titulo.toLowerCase()));
    }

    public ListaEnlazada<Libro> buscarPorEditorial(String editorial) {
        return libros.filtrar(l -> l.getEditorial().toLowerCase().contains(editorial.toLowerCase()));
    }

    public ListaEnlazada<Libro> obtenerTodos() {
        return libros;
    }


    public void guardarEnArchivo() {
        ArrayList<String> lineas = new ArrayList<>();
        Nodo<Libro> actual = libros.getCabeza();

        while (actual != null) {
            Libro l = actual.getDato();
            StringBuilder autoresStr = new StringBuilder();
            Nodo<Autor> actualAutor = l.getAutores().getCabeza();

            while (actualAutor != null) {
                Autor a = actualAutor.getDato();
                autoresStr.append(a.getCodigoAutor());

                if (actualAutor.getSiguiente() != null) {
                    autoresStr.append("|");
                }
                actualAutor = actualAutor.getSiguiente();
            }
            String linea = String.format("%s|%s|%s|%s|%s|%s",
                    l.getCodigoLibro(),
                    l.getTitulo(),
                    l.getISBN(),
                    l.getEditorial(),
                    l.getNumeroPaginas(),
                    autoresStr

            );
            lineas.add(linea);
            actual = actual.getSiguiente();


        }
        GestorArchivos.escribirLineas(nombreArchivo, lineas.toArray(new String[0]));
    }


    public void cargarDesdeArchivo() {
        String[] lineas = GestorArchivos.leerLineas(nombreArchivo);
        for (String linea : lineas) {
            String[] datos = GestorArchivos.parsearLinea(linea);
            if (datos.length == 6) {
                String[] autoresPartes = datos[5].split("\\|");
                Libro libro = new Libro( datos[0], datos[1], datos[2], datos[3], Integer.parseInt(datos[4]));
                for (String autorStr : autoresPartes){
                    String[] datosAutor = autorStr.split("\\|");
                    if (datosAutor.length == 3) {
                        Autor autor = new Autor(datosAutor[1], datosAutor[2]);
                        libro.agregarAutor(autor);
                    }
                }
                libros.agregar(libro);
            }

        }
    }


   }








