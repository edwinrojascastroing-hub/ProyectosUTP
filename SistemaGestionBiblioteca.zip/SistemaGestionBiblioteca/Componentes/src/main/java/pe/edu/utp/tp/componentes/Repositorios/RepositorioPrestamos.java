package pe.edu.utp.tp.componentes.Repositorios;

import pe.edu.utp.tp.componentes.EntidadesPrincipales.Prestamo;
import pe.edu.utp.tp.componentes.ListasEnlazadas.ListaEnlazada;
import pe.edu.utp.tp.componentes.ListasEnlazadas.Nodo;
import pe.edu.utp.tp.utilidades.GestorArchivos;

public class RepositorioPrestamos {
    private ListaEnlazada<Prestamo> prestamos;
    private String nombreArchivo;

    public RepositorioPrestamos(String nombreArchivo) {
        this.prestamos = new ListaEnlazada<>();
        this.nombreArchivo = nombreArchivo;
        cargarDesdeArchivo();
    }

    public boolean agregar(Prestamo prestamo) {
        if (buscarPorCodigo(prestamo.getCodigoPrestamo()) != null) {
            return false;
        }
        prestamos.agregar(prestamo);
        guardarEnArchivo();
        return true;
    }

    public Prestamo buscarPorCodigo(String codigo) {
        return prestamos.buscar(p -> p.getCodigoPrestamo().equals(codigo));
    }

    public ListaEnlazada<Prestamo> buscarPorUsuario(String codigoUsuario) {
        return prestamos.filtrar(p -> p.getCodigoUsuario().equals(codigoUsuario));
    }

    public ListaEnlazada<Prestamo> buscarActivos() {
        return prestamos.filtrar(Prestamo::estaActivo);
    }

    public ListaEnlazada<Prestamo> buscarActivosPorUsuario(String codigoUsuario) {
        return prestamos.filtrar(p -> p.getCodigoUsuario().equals(codigoUsuario) && p.estaActivo());
    }

    public Prestamo buscarActivoPorEjemplar(String codigoEjemplar) {
        return prestamos.buscar(p -> p.getCodigoEjemplar().equals(codigoEjemplar) && p.estaActivo());
    }


    public ListaEnlazada<Prestamo> obtenerTodos() {
        return prestamos;
    }

    public void actualizarPrestamo() {
        guardarEnArchivo();
    }

    private void guardarEnArchivo() {
        java.util.ArrayList<String> lineas = new java.util.ArrayList<>();
        Nodo<Prestamo> actual = prestamos.getCabeza();

        while (actual != null) {
            Prestamo p = actual.getDato();
            String linea = String.format("%s|%s|%s|%s|%s|%s|%b|%s",
                    p.getCodigoPrestamo(),
                    p.getCodigoUsuario(),
                    p.getCodigoEjemplar(),
                    GestorArchivos.formatearFecha(p.getFechaPrestamo()),
                    GestorArchivos.formatearFecha(p.getFechaDevolucionEsperada()),
                    GestorArchivos.formatearFecha(p.getFechaDevolucionReal()),
                    p.estaActivo(),
                    p.getObservaciones() != null ? p.getObservaciones() : ""
            );
            lineas.add(linea);
            actual = actual.getSiguiente();
        }

        GestorArchivos.escribirLineas(nombreArchivo, lineas.toArray(new String[0]));
    }

    private void cargarDesdeArchivo() {
        String[] lineas = GestorArchivos.leerLineas(nombreArchivo);

        for (String linea : lineas) {
            String[] datos = GestorArchivos.parsearLinea(linea);
            if (datos.length >= 5) {
                Prestamo prestamo = new Prestamo(
                        datos[0], datos[1], datos[2],
                        GestorArchivos.parsearFecha(datos[3]),
                        GestorArchivos.parsearFecha(datos[4])
                );

                if (datos.length > 5 && !datos[5].isEmpty()) {
                    prestamo.setFechaDevolucionReal(GestorArchivos.parsearFecha(datos[5]));
                }
                if (datos.length > 7 && !datos[7].isEmpty()) {
                    prestamo.setObservaciones(datos[7]);
                }

                prestamos.agregar(prestamo);
            }
        }
    }
}

