package pe.edu.utp.tp.componentes.Repositorios;

import pe.edu.utp.tp.componentes.EntidadesPrincipales.Autor;
import pe.edu.utp.tp.componentes.ListasEnlazadas.ListaEnlazada;
import pe.edu.utp.tp.componentes.ListasEnlazadas.Nodo;
import pe.edu.utp.tp.utilidades.GestorArchivos;


import java.util.ArrayList;

public class RepositorioAutores {
    private ListaEnlazada<Autor> autores;
    private String nombreArchivo;

    public RepositorioAutores(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
        this.autores = new ListaEnlazada<>();
        cargarDesdeArchivo();
    }


    public boolean agregar(Autor autor) {
        if (buscarPorCodigo(autor.getCodigoAutor()) != null){
            return false; // ya existe
        }
        autores.agregar(autor);
        guardarEnArchivo();
        return true;

    }


    public ListaEnlazada<Autor> obtenerTodos() {
        return autores;
    }


    public Autor buscarPorCodigo(String codigo) {
        return autores.buscar(a -> a.getCodigoAutor().equals(codigo));
    }
    public ListaEnlazada<Autor> buscarPorNombre(String nombre) {
        return autores.filtrar(a -> a.getNombreAutor().toLowerCase().contains(nombre.toLowerCase()));
    }

    public boolean eliminar(String codigo) {
        Autor autor = buscarPorCodigo(codigo);
        if (autor != null) {
            boolean eliminado = autores.eliminar(autor);
            if (eliminado) {
                guardarEnArchivo();
            }
            return eliminado;
        }
        return false;
    }

    // Convierte ListaEnlazada → String[] → Archivo
    public void guardarEnArchivo() {
         ArrayList<String> lineas = new ArrayList<>();
         Nodo<Autor> actual = autores.getCabeza();

         while (actual != null) {
             Autor a =actual.getDato();
             String linea = String.format("%s|%s",
                     a.getCodigoAutor(),
                     a.getNombreAutor()

             );
             lineas.add(linea);
             actual = actual.getSiguiente();

         }

         GestorArchivos.escribirLineas(nombreArchivo, lineas.toArray(new String[0]));

     }

    // Convierte Archivo → String[] → ListaEnlazada
    public void cargarDesdeArchivo() {
        // GestorArchivos retorna String[], no conoce ListaEnlazada
        String[] lineas = GestorArchivos.leerLineas(nombreArchivo);

        for (String linea : lineas) {
            String[] datos = GestorArchivos.parsearLinea(linea);
            if (datos.length >= 2) {
                Autor autor = new Autor(datos[0], datos[1]);
                autores.agregar(autor); // Aquí usamos ListaEnlazada
            }
        }
    }
}








