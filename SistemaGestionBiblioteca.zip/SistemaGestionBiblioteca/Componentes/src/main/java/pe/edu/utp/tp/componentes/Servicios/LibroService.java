package pe.edu.utp.tp.componentes.Servicios;

import pe.edu.utp.tp.componentes.EntidadesPrincipales.Autor;
import pe.edu.utp.tp.componentes.EntidadesPrincipales.Libro;
import pe.edu.utp.tp.componentes.ListasEnlazadas.ListaEnlazada;
import pe.edu.utp.tp.componentes.Repositorios.RepositorioAutores;
import pe.edu.utp.tp.componentes.Repositorios.RepositorioLibros;

public class LibroService {
    private RepositorioLibros repositorioLibros;
    private RepositorioAutores repositorioAutores;

    public LibroService(RepositorioLibros repoLibros, RepositorioAutores repoAutores) {
        this.repositorioLibros = repoLibros;
        this.repositorioAutores = repoAutores;
    }

    public boolean crear(String codigo, String titulo, String isbn, String editorial,
                         int numPaginas, ListaEnlazada<String> codigosAutores) {

        Libro libro = new Libro(codigo, titulo, isbn, editorial, numPaginas);
        // Agregar autores al libro
        codigosAutores.recorrer(codigoAutor -> {
            Autor autor = repositorioAutores.buscarPorCodigo(codigoAutor);
            if (autor != null) {
                libro.agregarAutor(autor);
            }
        });

        return repositorioLibros.agregar(libro);
    }

    public boolean actualizar(String codigo, String nuevoTitulo, String nuevaEditorial) {
        Libro libro = repositorioLibros.buscarPorCodigo(codigo);
        if (libro != null) {
            libro.setTitulo(nuevoTitulo);
            libro.setEditorial(nuevaEditorial);
            return true;
        }
        return false;
    }

    public Libro buscar(String codigo) {
        return repositorioLibros.buscarPorCodigo(codigo);
    }

    public ListaEnlazada<Libro> buscarPorTitulo(String titulo) {
        return repositorioLibros.buscarPorTitulo(titulo);
    }

    public ListaEnlazada<Libro> buscarPorEditorial(String editorial) {
        return repositorioLibros.buscarPorEditorial(editorial);
    }

    public ListaEnlazada<Libro> listarTodos() {
        return repositorioLibros.obtenerTodos();
    }
}
