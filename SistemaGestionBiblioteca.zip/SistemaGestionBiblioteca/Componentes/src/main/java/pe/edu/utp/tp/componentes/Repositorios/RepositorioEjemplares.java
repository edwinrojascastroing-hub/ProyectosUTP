package pe.edu.utp.tp.componentes.Repositorios;

import pe.edu.utp.tp.componentes.EntidadesPrincipales.Ejemplar;
import pe.edu.utp.tp.componentes.ListasEnlazadas.ListaEnlazada;
import pe.edu.utp.tp.componentes.ListasEnlazadas.Nodo;
import pe.edu.utp.tp.utilidades.GestorArchivos;

import java.util.ArrayList;

public class RepositorioEjemplares {
    private ListaEnlazada<Ejemplar> ejemplares;
    private String nombreArchivo;


    public RepositorioEjemplares(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
        this.ejemplares = new ListaEnlazada<>();
        cargarDesdeArchivo();
    }


    public boolean agregar(Ejemplar ejemplar) {
        if (buscarPorCodigo(ejemplar.getCodigoEjemplar()) != null) {
            return false;
        }
        ejemplares.agregar(ejemplar);
        actualizarEjemplar();
        return true;
    }

    public Ejemplar buscarPorCodigo(String codigo) {
        return ejemplares.buscar(e -> e.getCodigoEjemplar().equals(codigo));
    }

    public ListaEnlazada<Ejemplar> buscarPorLibro(String codigoLibro) {
        return ejemplares.filtrar(e -> e.getCodigoLibro().equals(codigoLibro));
    }

    public ListaEnlazada<Ejemplar> buscarDisponiblesPorLibro(String codigoLibro) {
        return ejemplares.filtrar(e -> e.getCodigoLibro().equals(codigoLibro) && e.estaDisponible());
    }

    public ListaEnlazada<Ejemplar> obtenerTodos() {
        return ejemplares;
    }

    public void actualizarEjemplar() {
        guardarEnArchivo();
    }


    public void guardarEnArchivo(){
        ArrayList<String> lineas = new ArrayList <>();
        Nodo<Ejemplar> actual = ejemplares.getCabeza();

        while (actual != null){
            Ejemplar e= actual.getDato();

            String linea = String.format("%s|%s|%s|%s%n",
                    e.getCodigoEjemplar(),
                    e.getLocalizacion(),
                    e.getCodigoLibro(),
                    e.getEstado()
                    );
            lineas.add(linea);
            actual = actual.getSiguiente();
        }

        GestorArchivos.escribirLineas(nombreArchivo,lineas.toArray(new String[0]));
    }


    public void cargarDesdeArchivo(){
        String[] lineas = GestorArchivos.leerLineas(nombreArchivo);

        for(String linea: lineas){
            String[] datos = GestorArchivos.parsearLinea(linea);
            if(datos.length >= 4){
                Ejemplar ejemplar = new Ejemplar(datos[0],datos[1],datos[2], Ejemplar.EstadoEjemplar.valueOf(datos[3]));
                ejemplares.agregar(ejemplar);
            }


        }

    }
}
