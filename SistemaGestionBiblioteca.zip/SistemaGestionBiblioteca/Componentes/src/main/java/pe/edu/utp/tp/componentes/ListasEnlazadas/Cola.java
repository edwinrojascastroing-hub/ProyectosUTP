package pe.edu.utp.tp.componentes.ListasEnlazadas;

public class Cola<T> {

    Nodo<T> frente;
    Nodo<T> fin;
    int size;

    public Cola() {
        frente = null;
        fin = null;
        size = 0;
    }

    public void encolar(T dato) {
        Nodo<T> nuevo = new Nodo<>(dato);
        if (frente == null) {
            frente = fin = nuevo;
        }
        else {
            frente.siguiente = nuevo;
            fin = nuevo;

        }
    }

    public T desencolar() {
        if (frente == null) {
            throw new IllegalStateException("La cola está vacía");
        }

        T dato = frente.dato;
        frente = frente.siguiente;
        if (frente == null) {
         fin = null;
        }
        size--;
        return dato;

    }

    public T verFrente() {
        if (frente == null) {
            throw new IllegalStateException("La cola está vacía");
        }
        return frente.dato;
    }

    public boolean estaVacia() {
        return frente == null;
    }

    public int getSize() {
        return size;
    }







}


