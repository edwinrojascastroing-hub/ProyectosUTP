package pe.edu.utp.tp.componentes.Repositorios;

public final class GestorBiblioteca {

        private static GestorBiblioteca instancia;

    private final RepositorioAutores repositorioAutores;
    private final RepositorioLibros repositorioLibros;
    private final RepositorioEjemplares repositorioEjemplares;
    private final RepositorioUsuarios repositorioUsuarios;
    private final RepositorioPrestamos repositorioPrestamos;
        private static final String RUTA = "datos/";

        private GestorBiblioteca() {
            repositorioAutores = new RepositorioAutores(RUTA + "autores.txt");
            repositorioLibros = new RepositorioLibros(RUTA + "libros.txt");
           repositorioEjemplares= new RepositorioEjemplares(RUTA + "ejemplares.txt");
            repositorioUsuarios= new RepositorioUsuarios(RUTA + "usuarios.txt");
            repositorioPrestamos= new RepositorioPrestamos(RUTA + "prestamos.txt");
        }

        public static GestorBiblioteca getInstance() {
            if (instancia == null) {
                instancia = new GestorBiblioteca();
            }
            return instancia;
        }


        public RepositorioAutores getAutores() { return repositorioAutores; }
        public RepositorioLibros getLibros() { return repositorioLibros; }
        public RepositorioEjemplares getEjemplares() { return repositorioEjemplares; }
        public RepositorioUsuarios getUsuarios() { return repositorioUsuarios; }
        public RepositorioPrestamos getPrestamos() { return repositorioPrestamos; }
    }


