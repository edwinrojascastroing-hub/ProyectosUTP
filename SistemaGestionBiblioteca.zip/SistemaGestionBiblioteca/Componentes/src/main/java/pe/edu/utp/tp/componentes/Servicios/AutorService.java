package pe.edu.utp.tp.componentes.Servicios;

import pe.edu.utp.tp.componentes.EntidadesPrincipales.Autor;
import pe.edu.utp.tp.componentes.ListasEnlazadas.ListaEnlazada;
import pe.edu.utp.tp.componentes.Repositorios.RepositorioAutores;

public class AutorService {
    private RepositorioAutores repositorio;

    public AutorService(RepositorioAutores repositorio) {
        this.repositorio = repositorio;
    }

    public boolean crear(String codigo, String nombre) {
        Autor autor = new Autor(codigo, nombre);

        return repositorio.agregar(autor);
    }

    public boolean actualizar(String codigo, String nuevoNombre) {
        Autor autor = repositorio.buscarPorCodigo(codigo);
        if (autor != null) {
            autor.setNombreAutor(nuevoNombre);
            return true;
        }
        return false;
    }

    public boolean eliminar(String codigo) {
        return repositorio.eliminar(codigo);
    }

    public Autor buscar(String codigo) {
        return repositorio.buscarPorCodigo(codigo);
    }

    public ListaEnlazada<Autor> buscarPorNombre(String nombre) {
        return repositorio.buscarPorNombre(nombre);
    }

    public ListaEnlazada<Autor> listarTodos() {
        return repositorio.obtenerTodos();
    }
}


