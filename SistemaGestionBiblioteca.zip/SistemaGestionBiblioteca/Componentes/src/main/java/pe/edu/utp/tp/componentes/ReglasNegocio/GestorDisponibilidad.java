package pe.edu.utp.tp.componentes.ReglasNegocio;

import pe.edu.utp.tp.componentes.EntidadesPrincipales.Ejemplar;
import pe.edu.utp.tp.componentes.ListasEnlazadas.ListaEnlazada;
import pe.edu.utp.tp.componentes.Repositorios.RepositorioEjemplares;

public class GestorDisponibilidad {
    private RepositorioEjemplares repositorioEjemplares;

    public GestorDisponibilidad(RepositorioEjemplares repositorioEjemplares) {
        this.repositorioEjemplares = repositorioEjemplares;
    }

    public int consultarDisponibilidad(String codigoLibro) {
        ListaEnlazada<Ejemplar> disponibles= repositorioEjemplares.buscarDisponiblesPorLibro(codigoLibro);
        return disponibles.getSize();

    }

    public boolean marcarComoPrestado(String codigoEjemplar) {
        Ejemplar ejemplar = repositorioEjemplares.buscarPorCodigo(codigoEjemplar);
        if (ejemplar != null && ejemplar.estaDisponible()) {
            ejemplar.setEstado(Ejemplar.EstadoEjemplar.PRESTADO);
            repositorioEjemplares.guardarEnArchivo();

            return true;
        }
        return false;

    }

    public boolean marcarComoDisponible(String codigoEjemplar) {
        Ejemplar ejemplar = repositorioEjemplares.buscarPorCodigo(codigoEjemplar);
        if(ejemplar != null){
            ejemplar.setEstado(Ejemplar.EstadoEjemplar.DISPONIBLE);
            return true;
        }
        return false;
    }

    public ListaEnlazada<Ejemplar> obtenerDisponibles(String codigoLibro) {
        return repositorioEjemplares.buscarDisponiblesPorLibro(codigoLibro);

    }




}
