package pe.edu.utp.tp.componentes.EntidadesPrincipales;

public class Ejemplar {
    private String codigoEjemplar;
    private String localizacion;
    private String codigoLibro;
    private EstadoEjemplar estado;

public enum EstadoEjemplar {
        DISPONIBLE, PRESTADO, EN_REPARACION, PERDIDO
    }

    public Ejemplar(String codigoEjemplar, String localizacion, String codigoLibro, EstadoEjemplar estado) {
        this.codigoEjemplar = codigoEjemplar;
        this.localizacion = localizacion;
        this.codigoLibro = codigoLibro;
        this.estado = EstadoEjemplar.DISPONIBLE;
    }
    public Ejemplar(String codigoEjemplar, String localizacion, String codigoLibro) {
        this.codigoEjemplar = codigoEjemplar;
        this.localizacion = localizacion;
        this.codigoLibro = codigoLibro;
        this.estado = EstadoEjemplar.DISPONIBLE;
    }

    public String getCodigoEjemplar() {
        return codigoEjemplar;
    }

    public void setCodigoEjemplar(String codigoEjemplar) {
        this.codigoEjemplar = codigoEjemplar;
    }

    public String getLocalizacion() {
        return localizacion;
    }

    public void setLocalizacion(String localizacion) {
        this.localizacion = localizacion;
    }

    public String getCodigoLibro() {
        return codigoLibro;
    }

    public void setCodigoLibro(String codigoLibro) {
        this.codigoLibro = codigoLibro;
    }

    public EstadoEjemplar getEstado() {
        return estado;
    }

    public void setEstado(EstadoEjemplar estado) {
        this.estado = estado;
    }

    public boolean estaDisponible() {
        return estado == EstadoEjemplar.DISPONIBLE;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Ejemplar)) return false;
        Ejemplar otro = (Ejemplar) obj;
        return codigoEjemplar.equals(otro.codigoEjemplar);
    }

    @Override
    public String toString() {
        return "Ejemplar{" +
                "codigoEjemplar='" + codigoEjemplar + '\'' +
                ", localizacion='" + localizacion + '\'' +
                ", codigoLibro='" + codigoLibro + '\'' +
                ", estado=" + estado +
                '}';
    }
}
