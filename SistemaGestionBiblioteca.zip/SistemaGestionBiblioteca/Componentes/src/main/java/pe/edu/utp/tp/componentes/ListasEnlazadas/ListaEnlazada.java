package pe.edu.utp.tp.componentes.ListasEnlazadas;

import pe.edu.utp.tp.componentes.EntidadesPrincipales.Autor;

import java.util.function.Consumer;
import java.util.function.Predicate;

public class ListaEnlazada <T>{
    private Nodo<T> cabeza;
    private int size;



    public ListaEnlazada(){
        this.cabeza = null;
        this.size= 0;
    }


    public void agregar( T dato) {
        Nodo<T> nuevo = new Nodo<>(dato);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            Nodo<T> actual = cabeza;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }
            actual.siguiente = nuevo;
        }

        size++;
    }


    public boolean eliminar(T dato) {
        if (cabeza == null) {
            return false; // lista vacía
        }
        // Si el dato está en la cabeza
        if (cabeza.dato.equals(dato)) {
            cabeza = cabeza.siguiente;
            size --;
            return true;
        }
        Nodo<T> actual = cabeza;
        while (actual.siguiente != null) {
            if (actual.siguiente.dato.equals(dato)) {
                actual.siguiente = actual.siguiente.siguiente; // saltar el nodo
                size--;
                return true;
            }
            actual = actual.siguiente;
        }
        return false; // no se encontró el dato
    }


    public T buscar(Predicate<T> criterio) {
        Nodo<T> actual = cabeza;
        while (actual != null) {
            if (criterio.test(actual.dato)) {
                return actual.dato;
            }
            actual = actual.siguiente;
        }
        return null;
    }

    public ListaEnlazada<T> filtrar(Predicate<T> criterio) {
        ListaEnlazada<T> resultado = new ListaEnlazada<>();
        Nodo<T> actual = cabeza;
        while (actual != null) {
            if (criterio.test(actual.dato)) {
                resultado.agregar(actual.dato);
            }
            actual = actual.siguiente;
        }
        return resultado;
    }


    public int getSize() {
        return size;
    }

    public Nodo<T> getCabeza() {
        return cabeza;
    }

    public boolean estaVacia() {
        return cabeza == null;
    }

    public void recorrer(Consumer<T> accion) {
        Nodo<T> actual = cabeza;
        while (actual != null) {
            accion.accept(actual.dato);
            actual = actual.siguiente;
        }
    }
}






